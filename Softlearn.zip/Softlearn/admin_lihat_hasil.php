<?php
// admin_lihat_hasil.php
require_once 'config.php';

// Cek sesi admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["peran"] !== 'admin') {
    header("location: login.php");
    exit;
}
if (!isset($_GET['id_kuis'])) {
    header("location: admin_kelola_kuis.php");
    exit;
}

$id_kuis = intval($_GET['id_kuis']);
$nama_admin = htmlspecialchars($_SESSION["nama_lengkap"]);

// Ambil info kuis
$stmt_kuis = $mysqli->prepare("SELECT judul_kuis FROM Kuis WHERE id_kuis = ?");
$stmt_kuis->bind_param("i", $id_kuis);
$stmt_kuis->execute();
$result_kuis = $stmt_kuis->get_result();
if ($result_kuis->num_rows == 0) {
    header("location: admin_kelola_kuis.php"); exit;
}
$info_kuis = $result_kuis->fetch_assoc();
$stmt_kuis->close();

// Ambil hasil pengerjaan semua siswa untuk kuis ini
$sql_hasil = "
    SELECT 
        u.nama_lengkap, u.nis, u.kelas,
        hks.total_skor, hks.waktu_selesai, hks.status
    FROM Hasil_Kuis_Siswa hks
    JOIN Pengguna u ON hks.id_siswa = u.id_pengguna
    WHERE hks.id_kuis = ? AND u.peran = 'siswa'
    ORDER BY hks.total_skor DESC, hks.waktu_selesai ASC
";
$stmt_hasil = $mysqli->prepare($sql_hasil);
$stmt_hasil->bind_param("i", $id_kuis);
$stmt_hasil->execute();
$daftar_hasil = $stmt_hasil->get_result();
$stmt_hasil->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title>Hasil Kuis: <?php echo htmlspecialchars($info_kuis['judul_kuis']); ?> - Admin SoftLearn</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="student-dashboard-header">
        <div class="student-profile">
            <div class="profile-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#00388E"><path d="M12 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 12 1Zm-5 4.5A2.5 2.5 0 0 1 9.5 3H11v1.5a2.5 2.5 0 0 1-5 0V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h-5v-.5ZM12 7a2.5 2.5 0 0 1 2.5 2.5v.5h5v-.5A2.5 2.5 0 0 1 17 7h-1.5a2.5 2.5 0 0 1-2.5-2.5V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h3.5a1.5 1.5 0 0 1 1.5 1.5v12a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 2 21.5v-12A1.5 1.5 0 0 1 3.5 8H7V7a2.5 2.5 0 0 1 2.5-2.5V3h1.5A2.5 2.5 0 0 1 12 5.5V7Z"/></svg>
            </div>
            <span class="student-name"><?php echo $nama_admin; ?> (Admin)</span>
        </div>
        <a href="#" id="logout-btn" class="menu-logout-link">Logout</a>
    </div>

    <div class="container admin-container">
        <main class="student-dashboard-main page-content">
            <div class="page-header">
                <a href="admin_kelola_kuis.php" class="back-button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M10.8284 12.0007L15.7782 16.9504L14.364 18.3646L8 12.0007L14.364 5.63672L15.7782 7.05093L10.8284 12.0007Z"></path></svg>
                </a>
                <h1 class="page-title-text">Hasil Kuis: <?php echo htmlspecialchars($info_kuis['judul_kuis']); ?></h1>
            </div>

            <div class="admin-table-container">
                <h3>Peringkat Siswa</h3>
                <div class="table-wrapper">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Peringkat</th>
                                <th>Nama Siswa</th>
                                <th>NIS</th>
                                <th>Kelas</th>
                                <th>Skor Akhir</th>
                                <th>Waktu Selesai</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($daftar_hasil && $daftar_hasil->num_rows > 0): ?>
                                <?php $peringkat = 1; ?>
                                <?php while($hasil = $daftar_hasil->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $peringkat++; ?></td>
                                    <td><?php echo htmlspecialchars($hasil['nama_lengkap']); ?></td>
                                    <td><?php echo htmlspecialchars($hasil['nis']); ?></td>
                                    <td><?php echo htmlspecialchars($hasil['kelas']); ?></td>
                                    <td><strong><?php echo $hasil['total_skor']; ?></strong></td>
                                    <td><?php echo date('d M Y, H:i:s', strtotime($hasil['waktu_selesai'])); ?></td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6">Belum ada siswa yang mengerjakan kuis ini.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <div id="logout-confirm-modal" class="modal-overlay modal-hidden">
        <div class="modal-content">
            <h3>Konfirmasi Logout</h3>
            <p>Apakah Anda yakin ingin keluar dari sesi ini?</p>
            <div class="modal-actions">
                <button id="logout-cancel-btn" class="btn btn-secondary">Batal</button>
                <a href="logout.php" id="logout-confirm-btn" class="btn btn-danger">Ya, Logout</a>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const logoutLink = document.getElementById('logout-btn');
        const modal = document.getElementById('logout-confirm-modal');
        const cancelBtn = document.getElementById('logout-cancel-btn');

        if(logoutLink && modal) {
            logoutLink.addEventListener('click', function(event) {
                event.preventDefault(); // Mencegah link langsung redirect
                modal.classList.remove('modal-hidden');
            });

            function hideModal() {
                modal.classList.add('modal-hidden');
            }

            if (cancelBtn) {
                cancelBtn.addEventListener('click', hideModal);
            }

            modal.addEventListener('click', function(event) {
                if (event.target === modal) {
                    hideModal();
                }
            });
        }
    });
    </script>
</body>
</html>