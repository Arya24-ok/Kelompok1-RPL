<?php
// admin_kelola_kuis.php (Tombol Edit diubah menjadi kuning)
require_once 'config.php';

// Cek sesi admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["peran"] !== 'admin') {
    header("location: login.php");
    exit;
}

$nama_admin = htmlspecialchars($_SESSION["nama_lengkap"]);
$pesan_sukses = $pesan_error = "";

// Cek dan tampilkan pesan sukses dari halaman lain (seperti halaman edit)
if (isset($_SESSION['pesan_sukses_redirect'])) {
    $pesan_sukses = $_SESSION['pesan_sukses_redirect'];
    unset($_SESSION['pesan_sukses_redirect']);
}

// Logika untuk menghapus kuis
if (isset($_GET['hapus_kuis'])) {
    $id_kuis_hapus = intval($_GET['hapus_kuis']);
    $stmt = $mysqli->prepare("DELETE FROM Kuis WHERE id_kuis = ?");
    $stmt->bind_param("i", $id_kuis_hapus);
    if ($stmt->execute()) {
        $pesan_sukses = "Kuis berhasil dihapus beserta semua pertanyaan dan hasilnya.";
    } else {
        $pesan_error = "Gagal menghapus kuis.";
    }
    $stmt->close();
}

// Ambil semua data kuis untuk ditampilkan di tabel
$daftar_kuis_sql = "
    SELECT 
        k.id_kuis, k.judul_kuis, k.level_kesulitan, 
        mp.nama_mapel, 
        (SELECT COUNT(*) FROM Pertanyaan_Kuis pk WHERE pk.id_kuis = k.id_kuis) AS jumlah_soal,
        (SELECT COUNT(DISTINCT id_siswa) FROM Hasil_Kuis_Siswa hks WHERE hks.id_kuis = k.id_kuis) AS jumlah_pengerjaan
    FROM Kuis k
    JOIN Mata_Pelajaran mp ON k.id_mapel = mp.id_mapel
    ORDER BY k.tanggal_dibuat DESC
";
$daftar_kuis = $mysqli->query($daftar_kuis_sql);

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title>Kelola Kuis - Admin SoftLearn</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="student-dashboard-header">
        <div class="student-profile">
            <div class="profile-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#00388E"><path d="M12 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 12 1Zm-5 4.5A2.5 2.5 0 0 1 9.5 3H11v1.5a2.5 2.5 0 0 1-5 0V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h-5v-.5ZM12 7a2.5 2.5 0 0 1 2.5 2.5v.5h5v-.5A2.5 2.5 0 0 1 17 7h-1.5a2.5 2.5 0 0 1-2.5-2.5V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h3.5a1.5 1.5 0 0 1 1.5 1.5v12a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 2 21.5v-12A1.5 1.5 0 0 1 3.5 8H7V7a2.5 2.5 0 0 1 2.5-2.5V3h1.5A2.5 2.5 0 0 1 12 5.5V7Z"/></svg>
            </div>
            <span class="student-name"><?php echo $nama_admin; ?> (Admin)</span>
        </div>
        <a href="#" id="logout-btn" class="menu-logout-link">Logout</a>
    </div>

    <div class="container admin-container">
        <main class="student-dashboard-main page-content">
            <div class="page-header">
                <a href="dashboard_admin.php" class="back-button"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M10.8284 12.0007L15.7782 16.9504L14.364 18.3646L8 12.0007L14.364 5.63672L15.7782 7.05093L10.8284 12.0007Z"></path></svg></a>
                <h1 class="page-title-text">Manajemen Kuis</h1>
            </div>

            <?php if($pesan_sukses): ?><div class="success-message"><?php echo $pesan_sukses; ?></div><?php endif; ?>
            <?php if($pesan_error): ?><div class="error-message"><?php echo $pesan_error; ?></div><?php endif; ?>

            <div class="form-actions" style="justify-content: flex-end; margin-bottom: 20px;">
                <a href="admin_tambah_kuis.php" class="btn">Buat Kuis Baru</a>
            </div>

            <div class="admin-table-container">
                <h3>Daftar Kuis</h3>
                <div class="table-wrapper">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Judul Kuis</th>
                                <th>Mata Pelajaran</th>
                                <th>Soal</th>
                                <th>Pengerjaan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($daftar_kuis && $daftar_kuis->num_rows > 0): ?>
                                <?php while($kuis = $daftar_kuis->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($kuis['judul_kuis']); ?><br><small>Level: <?php echo htmlspecialchars($kuis['level_kesulitan']); ?></small></td>
                                    <td><?php echo htmlspecialchars($kuis['nama_mapel']); ?></td>
                                    <td><?php echo $kuis['jumlah_soal']; ?></td>
                                    <td><?php echo $kuis['jumlah_pengerjaan']; ?></td>
                                    <td class="action-buttons">
                                        <a href="admin_lihat_hasil.php?id_kuis=<?php echo $kuis['id_kuis']; ?>" class="btn-edit" style="background-color: #28a745;">Lihat Hasil</a>
                                        <a href="admin_edit_kuis.php?id=<?php echo $kuis['id_kuis']; ?>" class="btn-edit" style="background-color: #ffc107;">Edit</a>
                                        <a href="admin_kelola_kuis.php?hapus_kuis=<?php echo $kuis['id_kuis']; ?>" class="btn-delete" onclick="return confirm('PERINGATAN: Menghapus kuis ini akan menghapus semua pertanyaan dan data nilai siswa yang terkait. Apakah Anda yakin?');">Hapus</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5">Belum ada kuis yang dibuat.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    
    <div id="logout-confirm-modal" class="modal-overlay modal-hidden">
        <div class="modal-content">
            <h3>Konfirmasi Logout</h3>
            <p>Apakah Anda yakin ingin keluar dari sesi ini?</p>
            <div class="modal-actions">
                <button id="logout-cancel-btn" class="btn btn-secondary">Batal</button>
                <a href="logout.php" id="logout-confirm-btn" class="btn btn-danger">Ya, Logout</a>
            </div>
        </div>
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const logoutLink = document.getElementById('logout-btn');
        const modal = document.getElementById('logout-confirm-modal');
        const cancelBtn = document.getElementById('logout-cancel-btn');
        if(logoutLink && modal) {
            logoutLink.addEventListener('click', function(event) { event.preventDefault(); modal.classList.remove('modal-hidden'); });
            function hideModal() { modal.classList.add('modal-hidden'); }
            if (cancelBtn) { cancelBtn.addEventListener('click', hideModal); }
            modal.addEventListener('click', function(event) { if (event.target === modal) { hideModal(); } });
        }
    });
    </script>
</body>
</html>