<?php
// kuis_siswa.php
require_once 'config.php';

// Cek sesi
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["peran"] !== 'siswa') {
    header("location: login.php");
    exit;
}

$nama_siswa = htmlspecialchars($_SESSION["nama_lengkap"]);
$page_title = "Pilih Kuis"; // Judul default
$back_link = "dashboard_siswa.php";
$page_class = ""; // Variabel untuk kelas CSS tambahan

$selected_mapel_id = null;
$mata_pelajaran_list = [];
$kuis_list = [];

// Cek apakah mata pelajaran sudah dipilih
if (isset($_GET['mapel_id'])) {
    $selected_mapel_id = intval($_GET['mapel_id']);
    
    // Ambil nama mata pelajaran untuk judul
    $stmt_mapel = $mysqli->prepare("SELECT nama_mapel FROM Mata_Pelajaran WHERE id_mapel = ?");
    $stmt_mapel->bind_param("i", $selected_mapel_id);
    $stmt_mapel->execute();
    $result_mapel = $stmt_mapel->get_result();
    if($mapel_info = $result_mapel->fetch_assoc()) {
        $page_title = "Kuis: " . htmlspecialchars($mapel_info['nama_mapel']);
    }
    $stmt_mapel->close();
    
    // Ambil daftar kuis untuk mata pelajaran yang dipilih
    $sql_kuis = "
        SELECT 
            k.id_kuis, k.judul_kuis, k.level_kesulitan,
            (SELECT COUNT(*) FROM Pertanyaan_Kuis pk WHERE pk.id_kuis = k.id_kuis) AS jumlah_soal
        FROM Kuis k
        WHERE k.id_mapel = ?
        ORDER BY k.tanggal_dibuat DESC
    ";
    $stmt_kuis = $mysqli->prepare($sql_kuis);
    $stmt_kuis->bind_param("i", $selected_mapel_id);
    $stmt_kuis->execute();
    $result_kuis = $stmt_kuis->get_result();
    if ($result_kuis) {
        while ($row = $result_kuis->fetch_assoc()) {
            $kuis_list[] = $row;
        }
    }
    $stmt_kuis->close();
    $back_link = "kuis_siswa.php"; // Tombol kembali akan ke halaman pemilihan mapel

} else {
    // Jika belum ada mapel dipilih, tampilkan daftar mata pelajaran yang memiliki kuis
    $page_title = "Pilih Mata Pelajaran Kuis ✅"; // Judul yang Anda ubah
    $page_class = "mapel-selection-view"; // Tambahkan kelas khusus untuk tampilan ini
    $sql_mapel = "
        SELECT DISTINCT mp.id_mapel, mp.nama_mapel 
        FROM Mata_Pelajaran mp
        JOIN Kuis k ON mp.id_mapel = k.id_mapel
        ORDER BY mp.nama_mapel ASC
    ";
    $result_mapel = $mysqli->query($sql_mapel);
    if ($result_mapel) {
        while ($row = $result_mapel->fetch_assoc()) {
            $mata_pelajaran_list[] = $row;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title><?php echo $page_title; ?> - SoftLearn</title>
    <!-- Menambahkan versi (?v=1.6) untuk memaksa browser memuat CSS baru -->
    <link rel="stylesheet" href="style.css?v=1.6">
    <style>
        /* Style khusus untuk tombol Mulai Kuis */
        .btn-start-quiz {
            background-color: #1713C0;
            color: white;
            padding: 8px 18px;
            border-radius: 8px;
            font-weight: bold;
            font-size: 0.9em;
            text-align: center;
            transition: background-color 0.2s;
        }
        .content-list-item a:hover .btn-start-quiz {
            background-color: #110F9A;
        }
    </style>
</head>
<body class="dashboard-layout">
    <div class="student-dashboard-header">
        <div class="student-profile">
            <div class="profile-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#00388E"><path d="M12 2.5a.5.5 0 0 1 .5.5v1.255a7 7 0 0 1 5.422 5.422H19.25a.5.5 0 0 1 .5.5v2.586a.5.5 0 0 1-.146.353l-1.855 1.856a.5.5 0 0 1-.353.146H7.08a.5.5 0 0 1-.353-.146L4.872 12.62a.5.5 0 0 1-.146-.353V9.681a.5.5 0 0 1 .5-.5h1.327A7 7 0 0 1 11.5 4.255V3a.5.5 0 0 1 .5-.5ZM12 5a6 6 0 0 0-5.173 2.827A5.999 5.999 0 0 0 12 13a5.999 5.999 0 0 0 5.173-5.173A6 6 0 0 0 12 5Zm0 1.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"/><path d="M4.5 15.25a.5.5 0 0 1 .5-.5h14a.5.5 0 0 1 .5.5v2.017c0 .858-.338 1.674-1.007 2.343C17.08 20.919 14.89 21.5 12 21.5s-5.08-.581-6.493-1.89C4.838 18.94 4.5 18.125 4.5 17.267v-2.017Z"/></svg>
            </div>
            <span class="student-name"><?php echo $nama_siswa; ?></span>
        </div>
        <a href="#" id="logout-btn" class="menu-logout-link">Logout</a>
    </div>

    <div class="container">
        <main class="student-dashboard-main page-content <?php echo $page_class; ?>">
            <div class="page-header">
                 <a href="<?php echo $back_link; ?>" class="back-button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M10.8284 12.0007L15.7782 16.9504L14.364 18.3646L8 12.0007L14.364 5.63672L15.7782 7.05093L10.8284 12.0007Z"></path></svg>
                </a>
                <h1 class="page-title-text"><?php echo $page_title; ?></h1>
            </div>

            <?php if ($selected_mapel_id): ?>
                <!-- Tampilan Daftar Kuis per Mata Pelajaran -->
                <?php if (!empty($kuis_list)): ?>
                    <ul class="content-list">
                        <?php foreach ($kuis_list as $kuis): ?>
                            <li class="content-list-item">
                                <a href="pengerjaan_kuis.php?id_kuis=<?php echo $kuis['id_kuis']; ?>">
                                    <div class="item-icon kuis-icon-list">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H17.5A2.5 2.5 0 0 1 20 4.5v15A2.5 2.5 0 0 1 17.5 22H6.5A2.5 2.5 0 0 1 4 19.5v-15ZM6.5 3.5c-.276 0-.5.224-.5.5v15c0 .276.224.5.5.5H8V18a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v1.5h1.5c.276 0 .5-.224.5-.5v-15c0-.276-.224-.5-.5-.5H6.5Z"></path></svg>
                                    </div>
                                    <div class="item-info">
                                        <span class="item-title"><?php echo htmlspecialchars($kuis['judul_kuis']); ?></span>
                                        <span class="item-description">
                                            Level: <strong class="level-<?php echo strtolower(htmlspecialchars($kuis['level_kesulitan'])); ?>"><?php echo htmlspecialchars($kuis['level_kesulitan']); ?></strong> | <?php echo $kuis['jumlah_soal']; ?> Soal
                                        </span>
                                    </div>
                                    <div class="item-action">
                                        <div class="btn-start-quiz">Mulai</div>
                                    </div>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="no-content">Belum ada kuis untuk mata pelajaran ini.</p>
                <?php endif; ?>

            <?php else: ?>
                <!-- Tampilan Daftar Mata Pelajaran -->
                <?php if (!empty($mata_pelajaran_list)): ?>
                    <div class="mapel-grid">
                        <?php foreach ($mata_pelajaran_list as $mapel): ?>
                            <a href="kuis_siswa.php?mapel_id=<?php echo $mapel['id_mapel']; ?>" class="mapel-card">
                                <div class="mapel-card-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="36" height="36"><path d="M3 18.5V5.5A1.5 1.5 0 0 1 4.5 4h15A1.5 1.5 0 0 1 21 5.5v13A1.5 1.5 0 0 1 19.5 20h-15A1.5 1.5 0 0 1 3 18.5ZM19.5 5H4.5a.5.5 0 0 0-.5.5v13a.5.5 0 0 0 .5.5h15a.5.5 0 0 0 .5-.5V5.5a.5.5 0 0 0-.5-.5ZM12 12.4142L15.2929 9.12132L16.7071 10.5355L12 15.2426L7.29289 10.5355L8.70711 9.12132L12 12.4142Z"></path></svg>
                                </div>
                                <span class="mapel-card-title"><?php echo htmlspecialchars($mapel['nama_mapel']); ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="no-content">Belum ada kuis yang tersedia.</p>
                <?php endif; ?>
            <?php endif; ?>
        </main>
    </div>

       <!-- Modal Konfirmasi Logout -->
    <div id="logout-confirm-modal" class="modal-overlay modal-hidden">
        <div class="modal-content">
            <h3>Konfirmasi Logout</h3>
            <p>Apakah Anda yakin ingin keluar dari sesi ini?</p>
            <div class="modal-actions">
                <button id="logout-cancel-btn" class="btn btn-secondary">Batal</button>
                <a href="logout.php" id="logout-confirm-btn" class="btn btn-danger">Ya, Logout</a>
            </div>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const logoutLink = document.getElementById('logout-btn');
    const modal = document.getElementById('logout-confirm-modal');
    const cancelBtn = document.getElementById('logout-cancel-btn');

    if(logoutLink && modal) {
        logoutLink.addEventListener('click', function(event) {
            event.preventDefault(); // Mencegah link langsung redirect
            modal.classList.remove('modal-hidden');
        });

        function hideModal() {
            modal.classList.add('modal-hidden');
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', hideModal);
        }

        modal.addEventListener('click', function(event) {
            if (event.target === modal) {
                hideModal();
            }
        });
    }
});
</script>
    
</body>
</html>
