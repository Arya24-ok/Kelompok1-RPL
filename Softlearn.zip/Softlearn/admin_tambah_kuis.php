<?php
// admin_tambah_kuis.php
require_once 'config.php';

// Cek sesi admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["peran"] !== 'admin') {
    header("location: login.php");
    exit;
}

$nama_admin = htmlspecialchars($_SESSION["nama_lengkap"]);
$admin_id = $_SESSION["id_pengguna"];
$pesan_sukses = $pesan_error = "";

// Ambil daftar mata pelajaran untuk dropdown
$daftar_mapel = $mysqli->query("SELECT * FROM Mata_Pelajaran ORDER BY nama_mapel");

// Logika untuk menangani form submit
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['simpan_kuis'])) {
    // Validasi dasar
    if (empty($_POST['judul_kuis']) || empty($_POST['id_mapel']) || !isset($_POST['pertanyaan'])) {
        $pesan_error = "Judul kuis, mata pelajaran, dan minimal satu pertanyaan harus diisi.";
    } else {
        $mysqli->begin_transaction();
        try {
            // 1. Simpan detail kuis
            $judul_kuis = $_POST['judul_kuis'];
            $id_mapel = $_POST['id_mapel'];
            $level = $_POST['level_kesulitan'];
            $deskripsi = $_POST['deskripsi'];
            $waktu_pengerjaan = $_POST['waktu_pengerjaan_menit'];

            $stmt_kuis = $mysqli->prepare("INSERT INTO Kuis (id_mapel, judul_kuis, deskripsi, level_kesulitan, id_pembuat, waktu_pengerjaan_menit) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt_kuis->bind_param("isssii", $id_mapel, $judul_kuis, $deskripsi, $level, $admin_id, $waktu_pengerjaan);
            $stmt_kuis->execute();
            $id_kuis_baru = $stmt_kuis->insert_id;
            $stmt_kuis->close();

            // 2. Simpan setiap pertanyaan
            $stmt_pertanyaan = $mysqli->prepare("INSERT INTO Pertanyaan_Kuis (id_kuis, teks_pertanyaan, opsi_jawaban_json, kunci_jawaban, poin) VALUES (?, ?, ?, ?, ?)");
            
            foreach ($_POST['pertanyaan'] as $index => $data) {
                if (empty($data['teks']) || empty($data['opsi_a']) || empty($data['opsi_b']) || empty($data['opsi_c']) || empty($data['opsi_d']) || empty($data['kunci'])) {
                    throw new Exception("Semua field pada Pertanyaan #".($index+1)." harus diisi.");
                }
                $teks = $data['teks'];
                $kunci_jawaban = $data['kunci'];
                $poin = $data['poin'];
                $opsi = [
                    'A' => $data['opsi_a'],
                    'B' => $data['opsi_b'],
                    'C' => $data['opsi_c'],
                    'D' => $data['opsi_d']
                ];
                $opsi_json = json_encode($opsi);

                $stmt_pertanyaan->bind_param("isssi", $id_kuis_baru, $teks, $opsi_json, $kunci_jawaban, $poin);
                $stmt_pertanyaan->execute();
            }
            $stmt_pertanyaan->close();
            
            $mysqli->commit();
            $pesan_sukses = "Kuis berhasil disimpan! <a href='admin_kelola_kuis.php'>Kembali ke daftar kuis</a>";

        } catch (Exception $e) {
            $mysqli->rollback();
            $pesan_error = "Gagal menyimpan kuis: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title>Tambah Kuis Baru - Admin SoftLearn</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="student-dashboard-header">
        <div class="student-profile">
            <div class="profile-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#00388E"><path d="M12 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 12 1Zm-5 4.5A2.5 2.5 0 0 1 9.5 3H11v1.5a2.5 2.5 0 0 1-5 0V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h-5v-.5ZM12 7a2.5 2.5 0 0 1 2.5 2.5v.5h5v-.5A2.5 2.5 0 0 1 17 7h-1.5a2.5 2.5 0 0 1-2.5-2.5V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h3.5a1.5 1.5 0 0 1 1.5 1.5v12a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 2 21.5v-12A1.5 1.5 0 0 1 3.5 8H7V7a2.5 2.5 0 0 1 2.5-2.5V3h1.5A2.5 2.5 0 0 1 12 5.5V7Z"/></svg>
            </div>
            <span class="student-name"><?php echo $nama_admin; ?> (Admin)</span>
        </div>
        <a href="#" id="logout-btn" class="menu-logout-link">Logout</a>
    </div>

    <div class="container admin-container">
        <main class="student-dashboard-main page-content">
            <div class="page-header">
                <a href="admin_kelola_kuis.php" class="back-button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M10.8284 12.0007L15.7782 16.9504L14.364 18.3646L8 12.0007L14.364 5.63672L15.7782 7.05093L10.8284 12.0007Z"></path></svg>
                </a>
                <h1 class="page-title-text">Buat Kuis Baru</h1>
            </div>

            <?php if($pesan_sukses): ?><div class="success-message"><?php echo $pesan_sukses; ?></div><?php endif; ?>
            <?php if($pesan_error): ?><div class="error-message"><?php echo $pesan_error; ?></div><?php endif; ?>

            <form action="admin_tambah_kuis.php" method="post" id="quiz-form">
                <div class="admin-form-container">
                    <h3>Detail Kuis</h3>
                    <div class="form-group">
                        <label for="judul_kuis">Judul Kuis</label>
                        <input type="text" id="judul_kuis" name="judul_kuis" required placeholder="Contoh: Kuis Pengenalan HTML">
                    </div>
                     <div class="form-group">
                        <label for="id_mapel">Mata Pelajaran</label>
                        <select id="id_mapel" name="id_mapel" required>
                            <option value="">-- Pilih Mata Pelajaran --</option>
                            <?php if ($daftar_mapel->num_rows > 0): ?>
                                <?php $daftar_mapel->data_seek(0); ?>
                                <?php while($mapel = $daftar_mapel->fetch_assoc()): ?>
                                    <option value="<?php echo $mapel['id_mapel']; ?>">
                                        <?php echo htmlspecialchars($mapel['nama_mapel']); ?>
                                    </option>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                     <div class="form-group">
                        <label for="level_kesulitan">Level Kesulitan</label>
                        <select id="level_kesulitan" name="level_kesulitan" required>
                            <option value="Beginner">Beginner</option>
                            <option value="Intermediate">Intermediate</option>
                            <option value="Advanced">Advanced</option>
                            <option value="Expert">Expert</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="waktu_pengerjaan_menit">Durasi Kuis (menit)</label>
                        <input type="number" id="waktu_pengerjaan_menit" name="waktu_pengerjaan_menit" required placeholder="Contoh: 15" min="1" value="10">
                    </div>
                    <div class="form-group">
                        <label for="deskripsi">Deskripsi Singkat (Opsional)</label>
                        <textarea id="deskripsi" name="deskripsi" rows="3" placeholder="Jelaskan sedikit tentang kuis ini..."></textarea>
                    </div>
                </div>

                <div class="admin-form-container">
                    <h3>Pertanyaan Kuis</h3>
                    <div id="question-editor-container"></div>
                    <button type="button" id="add-question-btn" class="btn btn-secondary">Tambah Pertanyaan</button>
                </div>
                
                <div class="form-actions">
                    <button type="submit" name="simpan_kuis" class="btn">Simpan Kuis dan Pertanyaan</button>
                </div>
            </form>
        </main>
    </div>

    <div id="logout-confirm-modal" class="modal-overlay modal-hidden">
        <div class="modal-content">
            <h3>Konfirmasi Logout</h3>
            <p>Apakah Anda yakin ingin keluar dari sesi ini?</p>
            <div class="modal-actions">
                <button id="logout-cancel-btn" class="btn btn-secondary">Batal</button>
                <a href="logout.php" id="logout-confirm-btn" class="btn btn-danger">Ya, Logout</a>
            </div>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // ==== PENAMBAHAN JAVASCRIPT UNTUK MODAL LOGOUT ====
    const logoutLink = document.getElementById('logout-btn');
    const modal = document.getElementById('logout-confirm-modal');
    const cancelBtn = document.getElementById('logout-cancel-btn');

    if(logoutLink && modal) {
        logoutLink.addEventListener('click', function(event) {
            event.preventDefault();
            modal.classList.remove('modal-hidden');
        });

        function hideModal() {
            modal.classList.add('modal-hidden');
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', hideModal);
        }

        modal.addEventListener('click', function(event) {
            if (event.target === modal) {
                hideModal();
            }
        });
    }

    // Kode untuk menambah/menghapus form pertanyaan (TIDAK DIUBAH)
    const container = document.getElementById('question-editor-container');
    const addBtn = document.getElementById('add-question-btn');
    let questionCounter = 0;

    function addQuestionForm() {
        const questionIndex = questionCounter;
        const questionBlock = document.createElement('div');
        questionBlock.className = 'question-block';
        questionBlock.innerHTML = `
            <div class="question-header">
                <h4>Pertanyaan #${questionIndex + 1}</h4>
                <div class="form-group-inline">
                    <label for="poin_${questionIndex}">Poin</label>
                    <input type="number" id="poin_${questionIndex}" class="poin-input" name="pertanyaan[${questionIndex}][poin]" value="10" min="1" required>
                </div>
                <button type="button" class="btn-delete-question">&times;</button>
            </div>
            <div class="form-group">
                <label for="pertanyaan_teks_${questionIndex}">Teks Pertanyaan</label>
                <textarea id="pertanyaan_teks_${questionIndex}" name="pertanyaan[${questionIndex}][teks]" rows="3" required placeholder="Ketik teks pertanyaan di sini..."></textarea>
            </div>
            <div class="options-grid">
                <div class="option-input-group">
                    <input type="radio" name="pertanyaan[${questionIndex}][kunci]" value="A" required id="opsi_a_radio_${questionIndex}">
                    <label for="opsi_a_radio_${questionIndex}">A</label>
                    <input type="text" name="pertanyaan[${questionIndex}][opsi_a]" required placeholder="Opsi Jawaban A">
                </div>
                <div class="option-input-group">
                    <input type="radio" name="pertanyaan[${questionIndex}][kunci]" value="B" id="opsi_b_radio_${questionIndex}">
                    <label for="opsi_b_radio_${questionIndex}">B</label>
                    <input type="text" name="pertanyaan[${questionIndex}][opsi_b]" required placeholder="Opsi Jawaban B">
                </div>
                <div class="option-input-group">
                    <input type="radio" name="pertanyaan[${questionIndex}][kunci]" value="C" id="opsi_c_radio_${questionIndex}">
                    <label for="opsi_c_radio_${questionIndex}">C</label>
                    <input type="text" name="pertanyaan[${questionIndex}][opsi_c]" required placeholder="Opsi Jawaban C">
                </div>
                <div class="option-input-group">
                    <input type="radio" name="pertanyaan[${questionIndex}][kunci]" value="D" id="opsi_d_radio_${questionIndex}">
                    <label for="opsi_d_radio_${questionIndex}">D</label>
                    <input type="text" name="pertanyaan[${questionIndex}][opsi_d]" required placeholder="Opsi Jawaban D">
                </div>
            </div>
        `;
        
        container.appendChild(questionBlock);
        questionBlock.querySelector('.btn-delete-question').addEventListener('click', function() {
            questionBlock.remove();
            updateQuestionNumbers();
        });
        questionCounter++;
        updateQuestionNumbers();
    }

    function updateQuestionNumbers() {
        const allQuestions = container.querySelectorAll('.question-block');
        allQuestions.forEach((block, index) => {
            block.querySelector('h4').textContent = `Pertanyaan #${index + 1}`;
        });
    }
    addBtn.addEventListener('click', addQuestionForm);
    addQuestionForm(); // Tambah form pertanyaan pertama secara default
});
</script>
</body>
</html>