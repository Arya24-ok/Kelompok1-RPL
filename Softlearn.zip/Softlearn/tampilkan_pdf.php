<?php
// tampilkan_pdf.php
require_once 'config.php';

// Pastikan pengguna sudah login untuk keamanan
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    http_response_code(403);
    die("Akses ditolak. Silakan login.");
}

// Pastikan parameter id_materi ada dan tidak kosong
if (!isset($_GET['id_materi']) || empty($_GET['id_materi'])) {
    http_response_code(400);
    die("Error: ID Materi tidak ditemukan.");
}

$id_materi = intval($_GET['id_materi']);

// Ambil path file dari database berdasarkan id_materi
// Ini lebih aman daripada mengirimkan path file di URL
$stmt = $mysqli->prepare("SELECT file_path FROM Materi WHERE id_materi = ? AND tipe_konten = 'file_pdf'");
if (!$stmt) {
    http_response_code(500);
    die("Error: Gagal mempersiapkan statement SQL.");
}

$stmt->bind_param("i", $id_materi);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $materi = $result->fetch_assoc();
    $file_path = $materi['file_path'];

    // Periksa apakah file benar-benar ada di server
    if (!empty($file_path) && file_exists($file_path)) {
        // Atur header yang benar untuk memaksa browser menampilkan PDF inline
        header('Content-Type: application/pdf');
        // 'inline' memberitahu browser untuk mencoba menampilkan file, bukan mengunduh.
        header('Content-Disposition: inline; filename="' . basename($file_path) . '"');
        header('Content-Transfer-Encoding: binary');
        header('Accept-Ranges: bytes');
        header('Content-Length: ' . filesize($file_path));
        
        // Kosongkan output buffer sebelum mengirim file untuk menghindari korupsi file
        @ob_end_clean();
        
        // Baca file dan kirimkan ke output
        readfile($file_path);
        exit;
    } else {
        http_response_code(404);
        die("File tidak ditemukan di server pada path: " . htmlspecialchars($file_path));
    }
} else {
    http_response_code(404);
    die("Materi dengan ID tersebut tidak ditemukan atau bukan file PDF.");
}

$stmt->close();
$mysqli->close();
?>
