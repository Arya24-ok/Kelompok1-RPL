<?php
// pengerjaan_kuis.php
require_once 'config.php';

// Cek sesi
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["peran"] !== 'siswa') {
    header("location: login.php");
    exit;
}

// Pastikan id_kuis ada
if (!isset($_GET['id_kuis']) || empty($_GET['id_kuis'])) {
    header("location: kuis_siswa.php");
    exit;
}

$id_kuis = intval($_GET['id_kuis']);
$id_siswa = $_SESSION['id_pengguna'];

// Ambil info kuis
$stmt = $mysqli->prepare("
    SELECT judul_kuis, waktu_pengerjaan_menit, 
    (SELECT COUNT(*) FROM Pertanyaan_Kuis WHERE id_kuis = ?) AS total_soal 
    FROM Kuis WHERE id_kuis = ?
");
$stmt->bind_param("ii", $id_kuis, $id_kuis);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    header("location: kuis_siswa.php"); // Kuis tidak ditemukan
    exit;
}
$info_kuis = $result->fetch_assoc();
$stmt->close();

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title>Mengerjakan Kuis - SoftLearn</title>
    <link rel="stylesheet" href="style.css?v=1.7">
</head>
<body class="quiz-page-body">
    <!-- Lapisan Anti-Screenshot -->
    <div id="secure-overlay" class="secure-overlay"></div>

    <div id="quiz-container" class="quiz-container">
        <div class="quiz-header">
            <div class="quiz-progress-container">
                <div class="quiz-progress-bar" id="quiz-progress-bar"></div>
            </div>
            <div class="quiz-meta">
                <span id="question-counter">Soal 1/<?php echo $info_kuis['total_soal']; ?></span>
                <span id="quiz-timer"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18"><path d="M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2Zm0 2a8 8 0 1 0 0 16 8 8 0 0 0 0-16Zm1 3v5h4v2h-6V7h2Z"></path></svg> 
                    <span id="time-display">--:--</span>
                </span>
            </div>
        </div>

        <div class="quiz-question-area">
            <h2 id="question-text">Memuat soal...</h2>
        </div>

        <div class="quiz-options-area" id="options-container">
            <!-- Pilihan jawaban akan dimuat oleh JavaScript -->
        </div>
    </div>
    
    <div id="result-container" class="quiz-container result-container" style="display: none;">
        <h2 id="result-title">Kuis Selesai!</h2>
        <p id="result-message" style="font-size: 1.1em; color: #555;"></p>
        <div class="result-summary">
            <div class="result-item">
                <span class="result-label">Skor Akhir</span>
                <span class="result-value" id="final-score">0</span>
            </div>
            <div class="result-item">
                <span class="result-label">Jawaban Benar</span>
                <span class="result-value" id="correct-answers">0</span>
            </div>
            <div class="result-item">
                <span class="result-label">Jawaban Salah</span>
                <span class="result-value" id="wrong-answers">0</span>
            </div>
        </div>
        <a href="kuis_siswa.php" class="btn">Kembali ke Daftar Kuis</a>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const quizContainer = document.getElementById('quiz-container');
    const resultContainer = document.getElementById('result-container');
    const questionText = document.getElementById('question-text');
    const optionsContainer = document.getElementById('options-container');
    const questionCounter = document.getElementById('question-counter');
    const progressBar = document.getElementById('quiz-progress-bar');
    const timerDisplay = document.getElementById('time-display');
    
    const idKuis = <?php echo $id_kuis; ?>;
    const idSiswa = <?php echo $id_siswa; ?>;
    const totalSoal = <?php echo $info_kuis['total_soal']; ?>;
    const durasiMenit = <?php echo $info_kuis['waktu_pengerjaan_menit']; ?>;
    
    let currentQuestionIndex = 0;
    let questions = [];
    let score = 0;
    let correctCount = 0;
    let wrongCount = 0;
    let quizTimer;
    let quizEnded = false;

    // --- FITUR ANTI-CURANG ---

    // 1. Deteksi pindah tab/window
    function handleVisibilityChange() {
        if (document.hidden && !quizEnded) {
            showResults('Kuis dihentikan karena Anda meninggalkan halaman pengerjaan.');
        }
    }
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // 2. Mencegah klik kanan untuk mempersulit inspect element
    document.addEventListener('contextmenu', event => event.preventDefault());

    // 3. Mencegah tombol kembali browser
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };

    // --- LOGIKA KUIS ---

    async function fetchQuizData() {
        try {
            const response = await fetch(`api_kuis.php?action=start&id_kuis=${idKuis}`);
            if (!response.ok) throw new Error('Gagal memuat data kuis');
            
            const data = await response.json();
            if(data.status === 'success') {
                questions = data.questions;
                if(questions.length > 0) {
                    displayQuestion(currentQuestionIndex);
                    startOverallTimer(durasiMenit); 
                } else {
                    questionText.textContent = 'Kuis ini belum memiliki soal.';
                }
            } else {
                questionText.textContent = data.message || 'Gagal memulai kuis.';
            }
        } catch (error) {
            questionText.textContent = `Terjadi kesalahan: ${error.message}`;
        }
    }

    function startOverallTimer(minutes) {
        let seconds = minutes * 60;
        quizTimer = setInterval(() => {
            if (quizEnded) {
                clearInterval(quizTimer);
                return;
            }
            const min = Math.floor(seconds / 60);
            const sec = seconds % 60;
            
            timerDisplay.textContent = `${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
            
            if (seconds <= 0) {
                showResults('Waktu pengerjaan kuis telah habis.');
            }
            
            seconds--;
        }, 1000);
    }

    function displayQuestion(index) {
        if (index >= questions.length) {
            showResults('Anda telah menyelesaikan semua soal!');
            return;
        }

        const question = questions[index];
        questionText.textContent = question.teks_pertanyaan;
        optionsContainer.innerHTML = '';
        
        const options = JSON.parse(question.opsi_jawaban_json);
        
        Object.keys(options).forEach(key => {
            const button = document.createElement('button');
            button.className = 'quiz-option-btn';
            button.dataset.key = key;
            
            const keySpan = document.createElement('span');
            keySpan.textContent = key;
            const textNode = document.createTextNode(options[key]);
            
            button.appendChild(keySpan);
            button.appendChild(textNode);
            
            button.onclick = () => handleAnswer(key, question.id_pertanyaan, button);
            optionsContainer.appendChild(button);
        });

        updateProgress();
    }

    async function handleAnswer(selectedKey, questionId, buttonEl) {
        if(quizEnded) return;
        
        document.querySelectorAll('.quiz-option-btn').forEach(btn => btn.disabled = true);
        
        const formData = new FormData();
        formData.append('action', 'submit');
        formData.append('id_kuis', idKuis);
        formData.append('id_siswa', idSiswa);
        formData.append('id_pertanyaan', questionId);
        formData.append('jawaban', selectedKey);
        
        try {
            const response = await fetch('api_kuis.php', { method: 'POST', body: formData });
            const result = await response.json();

            if (result.status === 'success') {
                if (result.correct) {
                    if(buttonEl) buttonEl.classList.add('correct');
                    score += parseInt(questions[currentQuestionIndex].poin, 10);
                    correctCount++;
                } else {
                    if(buttonEl) buttonEl.classList.add('incorrect');
                    wrongCount++;
                    const correctBtn = document.querySelector(`.quiz-option-btn[data-key="${result.correct_answer}"]`);
                    if(correctBtn) correctBtn.classList.add('correct');
                }
            }
            
            setTimeout(() => {
                currentQuestionIndex++;
                displayQuestion(currentQuestionIndex);
            }, 1000);

        } catch (error) {
            console.error('Error submitting answer:', error);
        }
    }
    
    function updateProgress() {
        questionCounter.textContent = `Soal ${currentQuestionIndex + 1}/${totalSoal}`;
        const progressPercentage = ((currentQuestionIndex + 1) / totalSoal) * 100;
        progressBar.style.width = `${progressPercentage}%`;
    }

    async function saveFinalScore() {
        const formData = new FormData();
        formData.append('action', 'finish_quiz');
        formData.append('id_kuis', idKuis);
        formData.append('id_siswa', idSiswa);
        formData.append('total_skor', score);
        
        try {
            await fetch('api_kuis.php', { method: 'POST', body: formData });
        } catch (error) {
            console.error('Error saving final score:', error);
        }
    }

    function showResults(message = '') {
        if (quizEnded) return;
        quizEnded = true;

        clearInterval(quizTimer); 
        document.removeEventListener('visibilitychange', handleVisibilityChange); // Hapus listener setelah kuis selesai
        saveFinalScore();

        quizContainer.style.display = 'none';
        resultContainer.style.display = 'block';

        document.getElementById('result-title').textContent = message ? 'Kuis Dihentikan' : 'Kuis Selesai!';
        document.getElementById('result-message').textContent = message;
        document.getElementById('final-score').textContent = score;
        document.getElementById('correct-answers').textContent = correctCount;
        document.getElementById('wrong-answers').textContent = wrongCount;
    }

    fetchQuizData();
});
</script>
</body>
</html>
