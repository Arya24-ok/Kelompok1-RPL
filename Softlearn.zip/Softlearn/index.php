<?php
// index.php
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title>Selamat Datang di SoftLearn</title>
    <link rel="stylesheet" href="style.css?v=1.5">
</head>
<body class="index-page"> <!-- Menambahkan kelas 'index-page' untuk penataan tengah -->

    <div class="splash-container">
        <div class="splash-logo">
            <span class="logo-soft">Soft</span><span class="logo-learn">learn.</span>
        </div>
        <a href="login.php" class="btn btn-splash">Mulai Belajar</a>
    </div>

    <!-- Footer Universal -->
    <div class="site-footer">
        &copy; <?php echo date("Y"); ?> SoftLearn (Sistem Pembelajaran Online Interaktif untuk Kelas X SMK Jurusan RPL) - Kelompok 1 PTI 2023 B.
    </div>

</body>
</html>
