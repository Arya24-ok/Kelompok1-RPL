<?php
// materi_siswa.php
require_once 'config.php';

// Cek apakah pengguna sudah login dan perannya adalah siswa
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["peran"] !== 'siswa') {
    header("location: login.php");
    exit;
}

$nama_siswa = htmlspecialchars($_SESSION["nama_lengkap"]);
$id_siswa = $_SESSION["id_pengguna"];

// Variabel untuk menyimpan daftar mata pelajaran dan materi
$mata_pelajaran_list = [];
$materi_list = [];
$selected_mapel_id = null;
$selected_mapel_nama = "";
$selected_materi_id = null;
$detail_materi = null;
$page_title = "Ayo Belajar!! 🔥🔥🔥"; // Judul halaman default
$back_link = "dashboard_siswa.php"; // Link kembali default

// Ambil daftar semua mata pelajaran
$sql_mapel = "SELECT id_mapel, nama_mapel FROM Mata_Pelajaran ORDER BY nama_mapel ASC";
if($result_mapel = $mysqli->query($sql_mapel)){
    if ($result_mapel->num_rows > 0) {
        while ($row_mapel = $result_mapel->fetch_assoc()) {
            $mata_pelajaran_list[] = $row_mapel;
        }
    }
}


// Jika ada parameter mapel_id di URL, tampilkan daftar materi
if (isset($_GET['mapel_id']) && !isset($_GET['materi_id'])) {
    $selected_mapel_id = intval($_GET['mapel_id']);
    $back_link = "materi_siswa.php"; // Jika melihat daftar materi, kembali ke daftar mapel

    $stmt_nama_mapel = $mysqli->prepare("SELECT nama_mapel FROM Mata_Pelajaran WHERE id_mapel = ?");
    if($stmt_nama_mapel){
        $stmt_nama_mapel->bind_param("i", $selected_mapel_id);
        $stmt_nama_mapel->execute();
        $result_nama_mapel = $stmt_nama_mapel->get_result();
        if ($result_nama_mapel->num_rows == 1) {
            $selected_mapel_nama = $result_nama_mapel->fetch_assoc()['nama_mapel'];
            $page_title = "Materi: " . htmlspecialchars($selected_mapel_nama);
        }
        $stmt_nama_mapel->close();
    }

    $sql_materi = "SELECT id_materi, judul_materi, deskripsi FROM Materi WHERE id_mapel = ? ORDER BY tanggal_upload DESC";
    if ($stmt_materi = $mysqli->prepare($sql_materi)) {
        $stmt_materi->bind_param("i", $selected_mapel_id);
        $stmt_materi->execute();
        $result_materi = $stmt_materi->get_result();
        if ($result_materi->num_rows > 0) {
            while ($row_materi = $result_materi->fetch_assoc()) {
                $materi_list[] = $row_materi;
            }
        }
        $stmt_materi->close();
    }
}

// Jika ada parameter materi_id di URL, tampilkan detail materi
if (isset($_GET['materi_id'])) {
    $selected_materi_id = intval($_GET['materi_id']);
    $sql_detail_materi = "SELECT m.*, mp.nama_mapel, mp.id_mapel as mapel_id_from_materi, u.nama_lengkap AS nama_uploader 
                          FROM Materi m 
                          JOIN Mata_Pelajaran mp ON m.id_mapel = mp.id_mapel
                          JOIN Pengguna u ON m.id_uploader = u.id_pengguna
                          WHERE m.id_materi = ?";
    if ($stmt_detail = $mysqli->prepare($sql_detail_materi)) {
        $stmt_detail->bind_param("i", $selected_materi_id);
        $stmt_detail->execute();
        $result_detail = $stmt_detail->get_result();
        if ($result_detail->num_rows == 1) {
            $detail_materi = $result_detail->fetch_assoc();
            $page_title = htmlspecialchars($detail_materi['judul_materi']);
            $selected_mapel_id = $detail_materi['mapel_id_from_materi'];
            $back_link = "materi_siswa.php?mapel_id=" . $selected_mapel_id; // Jika melihat detail, kembali ke daftar materi dari mapel yg sama
        }
        $stmt_detail->close();
    }
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title><?php echo $page_title; ?> - SoftLearn</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="student-dashboard-header">
        <div class="student-profile">
            <div class="profile-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#00388E"><path d="M12 2.5a.5.5 0 0 1 .5.5v1.255a7 7 0 0 1 5.422 5.422H19.25a.5.5 0 0 1 .5.5v2.586a.5.5 0 0 1-.146.353l-1.855 1.856a.5.5 0 0 1-.353.146H7.08a.5.5 0 0 1-.353-.146L4.872 12.62a.5.5 0 0 1-.146-.353V9.681a.5.5 0 0 1 .5-.5h1.327A7 7 0 0 1 11.5 4.255V3a.5.5 0 0 1 .5-.5ZM12 5a6 6 0 0 0-5.173 2.827A5.999 5.999 0 0 0 12 13a5.999 5.999 0 0 0 5.173-5.173A6 6 0 0 0 12 5Zm0 1.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"/><path d="M4.5 15.25a.5.5 0 0 1 .5-.5h14a.5.5 0 0 1 .5.5v2.017c0 .858-.338 1.674-1.007 2.343C17.08 20.919 14.89 21.5 12 21.5s-5.08-.581-6.493-1.89C4.838 18.94 4.5 18.125 4.5 17.267v-2.017Z"/></svg>
            </div>
            <span class="student-name"><?php echo $nama_siswa; ?></span>
        </div>
        <a href="#" id="logout-btn" class="menu-logout-link">Logout</a>
    </div>

    <div class="container">
        <main class="student-dashboard-main page-content">
            <div class="page-header">
                <a href="<?php echo $back_link; ?>" class="back-button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M10.8284 12.0007L15.7782 16.9504L14.364 18.3646L8 12.0007L14.364 5.63672L15.7782 7.05093L10.8284 12.0007Z"></path></svg>
                </a>
                <h1 class="page-title-text"><?php echo $page_title; ?></h1>
            </div>

            <?php if ($detail_materi): ?>
                <div class="materi-detail-container">
                    <p class="materi-meta">Mata Pelajaran: <?php echo htmlspecialchars($detail_materi['nama_mapel']); ?> | Diupload oleh: <?php echo htmlspecialchars($detail_materi['nama_uploader']); ?></p>
                    <hr>
                    <div class="materi-content-display">
                        <?php if (!empty($detail_materi['deskripsi'])): ?>
                            <p><strong>Deskripsi:</strong><br><?php echo nl2br(htmlspecialchars($detail_materi['deskripsi'])); ?></p>
                        <?php endif; ?>

                        <?php
                        switch ($detail_materi['tipe_konten']) {
                            case 'teks':
                                echo '<div class="materi-teks">' . nl2br(htmlspecialchars($detail_materi['konten_materi'])) . '</div>';
                                break;
                            case 'file_pdf':
                                // KODE PDF DIKEMBALIKAN SEPERTI SEMULA
                                if (!empty($detail_materi['file_path']) && file_exists($detail_materi['file_path'])) {
                                    $viewer_url = 'tampilkan_pdf.php?id_materi=' . $detail_materi['id_materi'];
                                    
                                    echo '<div class="materi-pdf-viewer">';
                                    echo '  <object data="' . $viewer_url . '" type="application/pdf" width="100%" height="700px">';
                                    echo '      <p>Browser Anda tidak mendukung penampil PDF. Silakan unduh file untuk melihatnya.</p>';
                                    echo '  </object>';
                                    echo '  <div class="pdf-viewer-footer">';
                                    echo '      <span>Tidak bisa melihat PDF di atas?</span>';
                                    echo '      <a href="' . htmlspecialchars($detail_materi['file_path']) . '" download class="btn-download-materi">Unduh Materi</a>';
                                    echo '  </div>';
                                    echo '</div>';
                                } else {
                                    echo '<p class="error-message">File PDF tidak ditemukan di server. Pastikan path file benar. Contoh path yang benar: <strong>uploads/materi/namafile.pdf</strong></p>';
                                }
                                break;
                            case 'video_embed':
                                if (strpos($detail_materi['konten_materi'], '<iframe') !== false) {
                                    echo '<div class="materi-video-embed">' . $detail_materi['konten_materi'] . '</div>';
                                } else {
                                    echo '<p>Format embed video tidak valid.</p>';
                                }
                                break;
                            case 'link_eksternal':
                                echo '<p>Materi ini tersedia di link eksternal: <a href="' . htmlspecialchars($detail_materi['konten_materi']) . '" target="_blank" class="external-link">' . htmlspecialchars($detail_materi['konten_materi']) . '</a></p>';
                                break;
                        }
                        ?>
                    </div>
                </div>

            <?php elseif ($selected_mapel_id): ?>
                <?php if (!empty($materi_list)): ?>
                    <ul class="content-list">
                        <?php foreach ($materi_list as $materi): ?>
                            <li class="content-list-item">
                                <a href="materi_siswa.php?materi_id=<?php echo $materi['id_materi']; ?>">
                                    <div class="item-icon materi-icon-list">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M4 2.5A1.5 1.5 0 0 1 5.5 1h13A1.5 1.5 0 0 1 20 2.5v19A1.5 1.5 0 0 1 18.5 23h-13A1.5 1.5 0 0 1 4 21.5v-19ZM5.5 2c-.276 0-.5.224-.5.5v19c0 .276.224.5.5.5h13c.276 0 .5-.224.5-.5v-19c0-.276-.224-.5-.5-.5h-13Z"></path></svg>
                                    </div>
                                    <div class="item-info">
                                        <span class="item-title"><?php echo htmlspecialchars($materi['judul_materi']); ?></span>
                                        <span class="item-description"><?php echo htmlspecialchars(substr($materi['deskripsi'] ?? '', 0, 70)) . (strlen($materi['deskripsi'] ?? '') > 70 ? '...' : ''); ?></span>
                                    </div>
                                    <div class="item-action">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M13.1717 12.0007L8.22192 7.05093L9.63614 5.63672L16.0001 12.0007L9.63614 18.3646L8.22192 16.9504L13.1717 12.0007Z"></path></svg>
                                    </div>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="no-content">Belum ada materi untuk mata pelajaran ini.</p>
                <?php endif; ?>

            <?php else: ?>
                <h2 class="sub-page-title">Pilih Mata Pelajaran</h2>
                <?php if (!empty($mata_pelajaran_list)): ?>
                    <div class="mapel-grid">
                        <?php foreach ($mata_pelajaran_list as $mapel): ?>
                            <a href="materi_siswa.php?mapel_id=<?php echo $mapel['id_mapel']; ?>" class="mapel-card">
                                <div class="mapel-card-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="36" height="36"><path d="M3 18.5V5.5A1.5 1.5 0 0 1 4.5 4h15A1.5 1.5 0 0 1 21 5.5v13A1.5 1.5 0 0 1 19.5 20h-15A1.5 1.5 0 0 1 3 18.5ZM19.5 5H4.5a.5.5 0 0 0-.5.5v13a.5.5 0 0 0 .5.5h15a.5.5 0 0 0 .5-.5V5.5a.5.5 0 0 0-.5-.5ZM12 12.4142L15.2929 9.12132L16.7071 10.5355L12 15.2426L7.29289 10.5355L8.70711 9.12132L12 12.4142Z"></path></svg>
                                </div>
                                <span class="mapel-card-title"><?php echo htmlspecialchars($mapel['nama_mapel']); ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="no-content">Belum ada mata pelajaran yang tersedia.</p>
                <?php endif; ?>
            <?php endif; ?>
        </main>
    </div>

    <div id="logout-confirm-modal" class="modal-overlay modal-hidden">
        <div class="modal-content">
            <h3>Konfirmasi Logout</h3>
            <p>Apakah Anda yakin ingin keluar dari sesi ini?</p>
            <div class="modal-actions">
                <button id="logout-cancel-btn" class="btn btn-secondary">Batal</button>
                <a href="logout.php" id="logout-confirm-btn" class="btn btn-danger">Ya, Logout</a>
            </div>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const logoutLink = document.getElementById('logout-btn');
    const modal = document.getElementById('logout-confirm-modal');
    const cancelBtn = document.getElementById('logout-cancel-btn');

    if(logoutLink && modal) {
        logoutLink.addEventListener('click', function(event) {
            event.preventDefault(); // Mencegah link langsung redirect
            modal.classList.remove('modal-hidden');
        });

        function hideModal() {
            modal.classList.add('modal-hidden');
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', hideModal);
        }

        modal.addEventListener('click', function(event) {
            if (event.target === modal) {
                hideModal();
            }
        });
    }
});
</script>
</body>
</html>