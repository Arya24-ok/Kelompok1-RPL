<?php
// config.php

// Pengaturan Database
define('DB_SERVER', 'localhost'); // Ganti dengan server database Anda
define('DB_USERNAME', 'root');    // Ganti dengan username database Anda
define('DB_PASSWORD', '');        // Ganti dengan password database Anda
define('DB_NAME', 'softlearn_db'); // Nama database yang telah Anda buat

// Membuat koneksi ke database
// Menggunakan @ untuk menekan warning default PHP jika koneksi gagal,
// karena kita akan menangani error secara manual.
$mysqli = @new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Periksa koneksi
// mysqli_connect_errno() mengembalikan kode error dari percobaan koneksi terakhir.
if (mysqli_connect_errno()) {
    // Jika koneksi gagal, hentikan skrip dan tampilkan pesan error
    // Sebaiknya jangan tampilkan error detail di production
    // mysqli_connect_error() mengembalikan deskripsi string dari error koneksi terakhir.
    die("ERROR: Tidak dapat terhubung ke database. " . mysqli_connect_error());
}

// Mengatur karakter set ke utf8mb4 untuk mendukung berbagai karakter
if (!$mysqli->set_charset("utf8mb4")) {
    // printf("Error loading character set utf8mb4: %s\n", $mysqli->error);
    // exit();
    // Untuk production, mungkin cukup log error ini daripada menghentikan skrip
    // Atau bisa juga ditambahkan die() jika ini kritikal
    // die("Error loading character set utf8mb4: " . $mysqli->error);
}

// Memulai sesi PHP
// Penting untuk manajemen login pengguna
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Fungsi dasar untuk sanitasi input (opsional, tapi direkomendasikan)
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Anda bisa menambahkan konstanta atau fungsi global lainnya di sini jika diperlukan
// Contoh: URL dasar aplikasi
// define('BASE_URL', 'http://localhost/softlearn/'); // Sesuaikan dengan URL Anda

?>
