<?php
// admin_edit_siswa.php
require_once 'config.php';

// Cek sesi admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["peran"] !== 'admin') {
    header("location: login.php");
    exit;
}

// Pastikan ID siswa ada di URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("location: admin_kelola_pengguna.php"); // Arahkan ke file yang benar jika ID tidak ada
    exit;
}

$id_siswa = intval($_GET['id']);
$nama_admin = htmlspecialchars($_SESSION["nama_lengkap"]);
$pesan_sukses = $pesan_error = "";
$siswa = null;

// Logika untuk UPDATE data siswa ketika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nama_lengkap = trim($_POST['nama_lengkap']);
    $username = trim($_POST['username']);
    $password = $_POST['password']; 
    $email = trim($_POST['email']);
    $nis = trim($_POST['nis']);
    $kelas = trim($_POST['kelas']);

    // Validasi dasar
    if (empty($nama_lengkap) || empty($username)) {
        $pesan_error = "Nama lengkap dan username tidak boleh kosong.";
    } else {
        // Cek duplikasi username 
        $stmt_check = $mysqli->prepare("SELECT id_pengguna FROM Pengguna WHERE username = ? AND id_pengguna != ?");
        $stmt_check->bind_param("si", $username, $id_siswa);
        $stmt_check->execute();
        $stmt_check->store_result();

        if ($stmt_check->num_rows > 0) {
            $pesan_error = "Username sudah digunakan oleh pengguna lain.";
        } else {
            if (!empty($password)) {
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                $sql_update = "UPDATE Pengguna SET nama_lengkap=?, username=?, password_hash=?, email=?, nis=?, kelas=? WHERE id_pengguna=?";
                $stmt_update = $mysqli->prepare($sql_update);
                $stmt_update->bind_param("ssssssi", $nama_lengkap, $username, $password_hash, $email, $nis, $kelas, $id_siswa);
            } else {
                $sql_update = "UPDATE Pengguna SET nama_lengkap=?, username=?, email=?, nis=?, kelas=? WHERE id_pengguna=?";
                $stmt_update = $mysqli->prepare($sql_update);
                $stmt_update->bind_param("sssssi", $nama_lengkap, $username, $email, $nis, $kelas, $id_siswa);
            }

            if ($stmt_update->execute()) {
                $pesan_sukses = "Data siswa berhasil diperbarui.";
            } else {
                $pesan_error = "Gagal memperbarui data siswa.";
            }
            $stmt_update->close();
        }
        $stmt_check->close();
    }
}

// Ambil data terbaru siswa dari database untuk ditampilkan di form
$stmt_get = $mysqli->prepare("SELECT * FROM Pengguna WHERE id_pengguna = ? AND peran = 'siswa'");
$stmt_get->bind_param("i", $id_siswa);
$stmt_get->execute();
$result = $stmt_get->get_result();
if ($result->num_rows === 1) {
    $siswa = $result->fetch_assoc();
} else {
    header("location: admin_kelola_pengguna.php"); // Arahkan ke file yang benar jika siswa tidak ditemukan
    exit;
}
$stmt_get->close();

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title>Edit Siswa: <?php echo htmlspecialchars($siswa['nama_lengkap']); ?> - Admin</title>
    <link rel="stylesheet" href="style.css?v=1.5">
</head>
<body>
    <div class="student-dashboard-header">
        <div class="student-profile">
            <div class="profile-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#00388E"><path d="M12 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 12 1Zm-5 4.5A2.5 2.5 0 0 1 9.5 3H11v1.5a2.5 2.5 0 0 1-5 0V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h-5v-.5ZM12 7a2.5 2.5 0 0 1 2.5 2.5v.5h5v-.5A2.5 2.5 0 0 1 17 7h-1.5a2.5 2.5 0 0 1-2.5-2.5V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h3.5a1.5 1.5 0 0 1 1.5 1.5v12a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 2 21.5v-12A1.5 1.5 0 0 1 3.5 8H7V7a2.5 2.5 0 0 1 2.5-2.5V3h1.5A2.5 2.5 0 0 1 12 5.5V7Z"/></svg>
            </div>
            <span class="student-name"><?php echo $nama_admin; ?> (Admin)</span>
        </div>
        <a href="#" id="logout-btn" class="menu-logout-link">Logout</a>
    </div>

    <div class="container admin-container">
        <main class="student-dashboard-main page-content">
            <div class="page-header">
                <a href="admin_kelola_pengguna.php" class="back-button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M10.8284 12.0007L15.7782 16.9504L14.364 18.3646L8 12.0007L14.364 5.63672L15.7782 7.05093L10.8284 12.0007Z"></path></svg>
                </a>
                <h1 class="page-title-text">Edit Data Siswa</h1>
            </div>

            <?php if($pesan_sukses): ?><div class="success-message"><?php echo $pesan_sukses; ?></div><?php endif; ?>
            <?php if($pesan_error): ?><div class="error-message"><?php echo $pesan_error; ?></div><?php endif; ?>

            <div class="admin-form-container">
                <form action="admin_edit_siswa.php?id=<?php echo $id_siswa; ?>" method="post">
                    <div class="form-group">
                        <label for="nama_lengkap">Nama Lengkap Siswa</label>
                        <input type="text" id="nama_lengkap" name="nama_lengkap" value="<?php echo htmlspecialchars($siswa['nama_lengkap']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($siswa['username']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password Baru</label>
                        <input type="password" id="password" name="password" placeholder="Kosongkan jika tidak ingin mengubah">
                    </div>
                     <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($siswa['email']); ?>">
                    </div>
                    <div class="form-group">
                        <label for="nis">NIS</label>
                        <input type="text" id="nis" name="nis" value="<?php echo htmlspecialchars($siswa['nis']); ?>">
                    </div>
                    <div class="form-group">
                        <label for="kelas">Kelas</label>
                        <select id="kelas" name="kelas" required>
                            <option value="">-- Pilih Kelas --</option>
                            <?php 
                            $kelas_list = ["X RPL 1", "X RPL 2", "X RPL 3"];
                            foreach ($kelas_list as $k) {
                                $selected = ($siswa['kelas'] == $k) ? 'selected' : '';
                                echo "<option value='$k' $selected>$k</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn">Update Data Siswa</button>
                    </div>
                </form>
            </div>
        </main>
    </div>

    <div id="logout-confirm-modal" class="modal-overlay modal-hidden">
        <div class="modal-content">
            <h3>Konfirmasi Logout</h3><p>Apakah Anda yakin ingin keluar dari sesi ini?</p>
            <div class="modal-actions">
                <button id="logout-cancel-btn" class="btn btn-secondary">Batal</button>
                <a href="logout.php" id="logout-confirm-btn" class="btn btn-danger">Ya, Logout</a>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const logoutLink = document.getElementById('logout-btn');
        const modal = document.getElementById('logout-confirm-modal');
        const cancelBtn = document.getElementById('logout-cancel-btn');
        if(logoutLink && modal) {
            logoutLink.addEventListener('click', function(event) {
                event.preventDefault();
                modal.classList.remove('modal-hidden');
            });
            function hideModal() { modal.classList.add('modal-hidden'); }
            if (cancelBtn) { cancelBtn.addEventListener('click', hideModal); }
            modal.addEventListener('click', function(event) { if (event.target === modal) { hideModal(); } });
        }
    });
    </script>
</body>
</html>