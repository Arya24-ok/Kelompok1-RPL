<?php
// admin_kelola_siswa.php (Dengan Tombol Edit)
require_once 'config.php';

// Cek sesi admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["peran"] !== 'admin') {
    header("location: login.php");
    exit;
}

$nama_admin = htmlspecialchars($_SESSION["nama_lengkap"]);
$current_admin_id = $_SESSION["id_pengguna"];
$pesan_sukses = $pesan_error = "";

// ... (Logika PHP untuk menambah dan menghapus pengguna tetap sama, tidak saya tampilkan lagi agar ringkas) ...
// Logika untuk menambah PENGGUNA SISWA baru
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['tambah_pengguna'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $nama_lengkap = trim($_POST['nama_lengkap']);
    $email = trim($_POST['email']);
    $nis = trim($_POST['nis']);
    $kelas = trim($_POST['kelas']);
    $peran = 'siswa'; // Peran di-hardcode menjadi 'siswa'

    if (empty($username) || empty($password) || empty($nama_lengkap)) {
        $pesan_error = "Username, password, dan nama lengkap harus diisi.";
    } else {
        $stmt_check = $mysqli->prepare("SELECT id_pengguna FROM Pengguna WHERE username = ?");
        $stmt_check->bind_param("s", $username);
        $stmt_check->execute();
        $stmt_check->store_result();
        if ($stmt_check->num_rows > 0) {
            $pesan_error = "Username sudah digunakan. Silakan pilih username lain.";
        } else {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $sql_insert = "INSERT INTO Pengguna (username, password_hash, nama_lengkap, email, peran, nis, kelas) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt_insert = $mysqli->prepare($sql_insert);
            $stmt_insert->bind_param("sssssss", $username, $password_hash, $nama_lengkap, $email, $peran, $nis, $kelas);
            if ($stmt_insert->execute()) {
                $pesan_sukses = "Siswa baru berhasil ditambahkan.";
            } else {
                $pesan_error = "Gagal menambahkan siswa baru: " . $stmt_insert->error;
            }
            $stmt_insert->close();
        }
        $stmt_check->close();
    }
}
// Logika untuk menghapus PENGGUNA SISWA
if (isset($_GET['hapus_pengguna'])) {
    $id_hapus = intval($_GET['hapus_pengguna']);
    if ($id_hapus == $current_admin_id) {
        $pesan_error = "Anda tidak dapat menghapus akun Anda sendiri.";
    } else {
        $stmt_hapus = $mysqli->prepare("DELETE FROM Pengguna WHERE id_pengguna = ? AND peran = 'siswa'");
        $stmt_hapus->bind_param("i", $id_hapus);
        if ($stmt_hapus->execute()) {
            if ($stmt_hapus->affected_rows > 0) {
                $pesan_sukses = "Akun siswa berhasil dihapus.";
            } else {
                $pesan_error = "Gagal menghapus: Pengguna tidak ditemukan atau bukan siswa.";
            }
        } else {
            $pesan_error = "Gagal menghapus pengguna.";
        }
        $stmt_hapus->close();
    }
}

// Ambil data PENGGUNA SISWA saja untuk ditampilkan di tabel
$daftar_pengguna = $mysqli->query("SELECT * FROM Pengguna WHERE peran = 'siswa' ORDER BY nama_lengkap");

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title>Kelola Akun Siswa - Admin SoftLearn</title>
    <link rel="stylesheet" href="style.css?v=1.5">
</head>
<body>
    <div class="student-dashboard-header">
        <div class="student-profile">
            <div class="profile-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#00388E"><path d="M12 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 12 1Zm-5 4.5A2.5 2.5 0 0 1 9.5 3H11v1.5a2.5 2.5 0 0 1-5 0V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h-5v-.5ZM12 7a2.5 2.5 0 0 1 2.5 2.5v.5h5v-.5A2.5 2.5 0 0 1 17 7h-1.5a2.5 2.5 0 0 1-2.5-2.5V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h3.5a1.5 1.5 0 0 1 1.5 1.5v12a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 2 21.5v-12A1.5 1.5 0 0 1 3.5 8H7V7a2.5 2.5 0 0 1 2.5-2.5V3h1.5A2.5 2.5 0 0 1 12 5.5V7Z"/></svg>
            </div>
            <span class="student-name"><?php echo $nama_admin; ?> (Admin)</span>
        </div>
        <a href="#" id="logout-btn" class="menu-logout-link">Logout</a>
    </div>

    <div class="container admin-container">
        <main class="student-dashboard-main page-content">
            <div class="page-header">
                <a href="dashboard_admin.php" class="back-button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M10.8284 12.0007L15.7782 16.9504L14.364 18.3646L8 12.0007L14.364 5.63672L15.7782 7.05093L10.8284 12.0007Z"></path></svg>
                </a>
                <h1 class="page-title-text">Kelola Akun Siswa</h1>
            </div>

            <?php if($pesan_sukses): ?><div class="success-message"><?php echo $pesan_sukses; ?></div><?php endif; ?>
            <?php if($pesan_error): ?><div class="error-message"><?php echo $pesan_error; ?></div><?php endif; ?>

            <div class="admin-form-container">
                <h3>Tambah Siswa Baru</h3>
                <form action="admin_kelola_siswa.php" method="post" id="add-user-form">
                    <div class="form-group"><label for="nama_lengkap">Nama Lengkap Siswa</label><input type="text" id="nama_lengkap" name="nama_lengkap" required></div>
                    <div class="form-group"><label for="username">Username</label><input type="text" id="username" name="username" required></div>
                    <div class="form-group"><label for="password">Password</label><input type="password" id="password" name="password" required></div>
                    <div class="form-group"><label for="email">Email (Opsional)</label><input type="email" id="email" name="email"></div>
                    <div class="form-group"><label for="nis">NIS</label><input type="text" id="nis" name="nis"></div>
                    <div class="form-group"><label for="kelas">Kelas</label><select id="kelas" name="kelas" required><option value="">-- Pilih Kelas --</option><option value="X RPL 1">X RPL 1</option><option value="X RPL 2">X RPL 2</option><option value="X RPL 3">X RPL 3</option></select></div>
                    <div class="form-actions"><button type="submit" name="tambah_pengguna" class="btn">Tambah Siswa</button></div>
                </form>
            </div>

            <div class="admin-table-container">
                <h3>Daftar Siswa Terdaftar</h3>
                <div class="table-wrapper">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Username</th>
                                <th>NIS</th>
                                <th>Kelas</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($daftar_pengguna && $daftar_pengguna->num_rows > 0): ?>
                                <?php while($pengguna = $daftar_pengguna->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($pengguna['nama_lengkap']); ?></td>
                                    <td><?php echo htmlspecialchars($pengguna['username']); ?></td>
                                    <td><?php echo htmlspecialchars($pengguna['nis'] ?? '-'); ?></td>
                                    <td><?php echo htmlspecialchars($pengguna['kelas'] ?? '-'); ?></td>
                                    <td class="action-buttons">
                                        <a href="admin_edit_siswa.php?id=<?php echo $pengguna['id_pengguna']; ?>" class="btn-edit">Edit</a>
                                        <a href="admin_kelola_siswa.php?hapus_pengguna=<?php echo $pengguna['id_pengguna']; ?>" class="btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus siswa ini?');">Hapus</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5">Belum ada siswa yang terdaftar.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>


    <div id="logout-confirm-modal" class="modal-overlay modal-hidden">
        <div class="modal-content">
            <h3>Konfirmasi Logout</h3>
            <p>Apakah Anda yakin ingin keluar dari sesi ini?</p>
            <div class="modal-actions">
                <button id="logout-cancel-btn" class="btn btn-secondary">Batal</button>
                <a href="logout.php" id="logout-confirm-btn" class="btn btn-danger">Ya, Logout</a>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const logoutLink = document.getElementById('logout-btn');
        const modal = document.getElementById('logout-confirm-modal');
        const cancelBtn = document.getElementById('logout-cancel-btn');
        if(logoutLink && modal) {
            logoutLink.addEventListener('click', function(event) {
                event.preventDefault();
                modal.classList.remove('modal-hidden');
            });
            function hideModal() { modal.classList.add('modal-hidden'); }
            if (cancelBtn) { cancelBtn.addEventListener('click', hideModal); }
            modal.addEventListener('click', function(event) { if (event.target === modal) { hideModal(); } });
        }
    });
    </script>
</body>
</html>