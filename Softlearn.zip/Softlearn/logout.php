<?php
// logout.php

// Memulai sesi
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Menghapus semua variabel sesi
$_SESSION = array();

// Menghancurkan sesi
if (session_destroy()) {
    // Mengarahkan ke halaman login setelah logout berhasil
    header("location: login.php");
    exit;
} else {
    // Jika ada masalah saat menghancurkan sesi (jarang terjadi)
    echo "Error: Tidak dapat logout. Silakan coba tutup browser Anda.";
    // Atau bisa juga langsung redirect ke login.php
    // header("location: login.php");
    // exit;
}
?>
