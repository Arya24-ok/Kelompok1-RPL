<?php
// forum_komunikasi.php
require_once 'config.php';

// Atur zona waktu default ke WIB (Waktu Indonesia Barat)
date_default_timezone_set('Asia/Jakarta');

// Cek sesi pengguna (siswa atau admin)
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

$nama_pengguna = htmlspecialchars($_SESSION["nama_lengkap"]);
$id_pengguna = $_SESSION["id_pengguna"];
$peran_pengguna = $_SESSION["peran"];
$pesan_error = "";

// Fungsi baru yang lebih akurat untuk memformat waktu
function format_waktu_forum($timestamp) {
    $waktu_pesan = new DateTime($timestamp);
    $sekarang = new DateTime('now');
    
    // Reset waktu ke awal hari untuk perbandingan tanggal yang akurat
    $tanggal_pesan = (clone $waktu_pesan)->setTime(0, 0, 0);
    $tanggal_sekarang = (clone $sekarang)->setTime(0, 0, 0);
    
    $selisih_hari = $tanggal_sekarang->diff($tanggal_pesan)->days;

    if ($selisih_hari == 0) {
        return 'Hari ini, ' . $waktu_pesan->format('H:i');
    } elseif ($selisih_hari == 1) {
        return 'Kemarin, ' . $waktu_pesan->format('H:i');
    } else {
        // Untuk format tanggal dalam Bahasa Indonesia
        $bulan = array (1 => 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des');
        $tanggal = $waktu_pesan->format('d');
        $nama_bulan = $bulan[(int)$waktu_pesan->format('n')];
        $tahun = $waktu_pesan->format('Y');
        $jam = $waktu_pesan->format('H:i');
        return $tanggal . ' ' . $nama_bulan . ' ' . $tahun . ', ' . $jam;
    }
}


// Logika untuk mengirim pesan
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty(trim($_POST['isi_pesan']))) {
    $isi_pesan = trim($_POST['isi_pesan']);

    $sql_kirim = "INSERT INTO Pesan_Forum (id_pengguna_pengirim, isi_pesan) VALUES (?, ?)";
    if ($stmt_kirim = $mysqli->prepare($sql_kirim)) {
        $stmt_kirim->bind_param("is", $id_pengguna, $isi_pesan);
        if (!$stmt_kirim->execute()) {
            $pesan_error = "Gagal mengirim pesan.";
        }
        $stmt_kirim->close();
        // Redirect untuk mencegah resubmit form saat refresh
        header("Location: forum_komunikasi.php");
        exit;
    }
}

// Ambil semua pesan dari database
$sql_pesan = "
    SELECT 
        pf.id_pesan, 
        pf.isi_pesan, 
        pf.waktu_kirim,
        u.id_pengguna,
        u.nama_lengkap AS pengirim,
        u.peran
    FROM Pesan_Forum pf
    JOIN Pengguna u ON pf.id_pengguna_pengirim = u.id_pengguna
    ORDER BY pf.waktu_kirim ASC
";
$daftar_pesan = $mysqli->query($sql_pesan);

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title>Forum Diskusi - SoftLearn</title>
    <link rel="stylesheet" href="style.css?v=1.3">
</head>
<body>
    <div class="student-dashboard-header">
        <div class="student-profile">
            <div class="profile-icon">
                <?php if ($peran_pengguna == 'admin'): ?>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#00388E"><path d="M12 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 12 1Zm-5 4.5A2.5 2.5 0 0 1 9.5 3H11v1.5a2.5 2.5 0 0 1-5 0V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h-5v-.5ZM12 7a2.5 2.5 0 0 1 2.5 2.5v.5h5v-.5A2.5 2.5 0 0 1 17 7h-1.5a2.5 2.5 0 0 1-2.5-2.5V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h3.5a1.5 1.5 0 0 1 1.5 1.5v12a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 2 21.5v-12A1.5 1.5 0 0 1 3.5 8H7V7a2.5 2.5 0 0 1 2.5-2.5V3h1.5A2.5 2.5 0 0 1 12 5.5V7Z"/></svg>
                <?php else: ?>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#00388E"><path d="M12 2.5a.5.5 0 0 1 .5.5v1.255a7 7 0 0 1 5.422 5.422H19.25a.5.5 0 0 1 .5.5v2.586a.5.5 0 0 1-.146.353l-1.855 1.856a.5.5 0 0 1-.353.146H7.08a.5.5 0 0 1-.353-.146L4.872 12.62a.5.5 0 0 1-.146-.353V9.681a.5.5 0 0 1 .5-.5h1.327A7 7 0 0 1 11.5 4.255V3a.5.5 0 0 1 .5-.5ZM12 5a6 6 0 0 0-5.173 2.827A5.999 5.999 0 0 0 12 13a5.999 5.999 0 0 0 5.173-5.173A6 6 0 0 0 12 5Zm0 1.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"/><path d="M4.5 15.25a.5.5 0 0 1 .5-.5h14a.5.5 0 0 1 .5.5v2.017c0 .858-.338 1.674-1.007 2.343C17.08 20.919 14.89 21.5 12 21.5s-5.08-.581-6.493-1.89C4.838 18.94 4.5 18.125 4.5 17.267v-2.017Z"/></svg>
                <?php endif; ?>
            </div>
            <span class="student-name"><?php echo $nama_pengguna; ?></span>
        </div>
        <a href="#" id="logout-btn" class="menu-logout-link">Logout</a>
    </div>

    <div class="container">
        <main class="student-dashboard-main page-content">
            <div class="page-header">
                <a href="<?php echo ($peran_pengguna == 'admin') ? 'dashboard_admin.php' : 'dashboard_siswa.php'; ?>" class="back-button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M10.8284 12.0007L15.7782 16.9504L14.364 18.3646L8 12.0007L14.364 5.63672L15.7782 7.05093L10.8284 12.0007Z"></path></svg>
                </a>
                <h1 class="page-title-text">Forum Diskusi 💬</h1>
            </div>
            
            <div class="chat-container">
                <div class="chat-box" id="chat-box">
                    <?php if ($daftar_pesan && $daftar_pesan->num_rows > 0): ?>
                        <?php while($pesan = $daftar_pesan->fetch_assoc()): ?>
                            <?php $is_own_message = $pesan['id_pengguna'] == $id_pengguna; ?>
                            <div class="chat-message <?php echo $is_own_message ? 'own-message' : 'other-message'; ?>">
                                <div class="message-bubble">
                                    <div class="message-sender-header">
                                        <div class="sender-info">
                                            <span class="message-sender"><?php echo $is_own_message ? 'Anda' : htmlspecialchars($pesan['pengirim']); ?></span>
                                            <span class="sender-role sender-role-<?php echo $pesan['peran']; ?>"><?php echo ucfirst($pesan['peran']); ?></span>
                                        </div>
                                        <span class="message-time"><?php echo format_waktu_forum($pesan['waktu_kirim']); ?></span>
                                    </div>
                                    <div class="message-content">
                                        <?php echo nl2br(htmlspecialchars($pesan['isi_pesan'])); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="no-content">Belum ada pesan. Mulailah percakapan!</p>
                    <?php endif; ?>
                </div>
                
                <form action="forum_komunikasi.php" method="post" class="chat-form">
                    <textarea name="isi_pesan" placeholder="Ketik pesan Anda..." required></textarea>
                    <button type="submit" class="btn-send">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M3.478 2.405a.5.5 0 0 0-.5.832l4.1 1.64-1.214 4.55a.5.5 0 0 0 .656.59l3.17-1.585 1.585 3.17a.5.5 0 0 0 .59.656l4.55-1.215 1.64 4.1a.5.5 0 0 0 .832-.5L21.595 3.478a.5.5 0 0 0-.572-.572L3.478 2.405Z"/></svg>
                    </button>
                </form>
            </div>

        </main>
    </div>

    <div id="logout-confirm-modal" class="modal-overlay modal-hidden">
        <div class="modal-content">
            <h3>Konfirmasi Logout</h3>
            <p>Apakah Anda yakin ingin keluar dari sesi ini?</p>
            <div class="modal-actions">
                <button id="logout-cancel-btn" class="btn btn-secondary">Batal</button>
                <a href="logout.php" id="logout-confirm-btn" class="btn btn-danger">Ya, Logout</a>
            </div>
        </div>
    </div>

    <script>
        // Auto scroll ke pesan terakhir
        var chatBox = document.getElementById('chat-box');
        if(chatBox) {
            chatBox.scrollTop = chatBox.scrollHeight;
        }

        // ==== PENAMBAHAN JAVASCRIPT UNTUK MODAL LOGOUT ====
        document.addEventListener('DOMContentLoaded', function() {
            const logoutLink = document.getElementById('logout-btn');
            const modal = document.getElementById('logout-confirm-modal');
            const cancelBtn = document.getElementById('logout-cancel-btn');

            if(logoutLink && modal) {
                logoutLink.addEventListener('click', function(event) {
                    event.preventDefault(); // Mencegah link langsung redirect
                    modal.classList.remove('modal-hidden');
                });

                function hideModal() {
                    modal.classList.add('modal-hidden');
                }

                if (cancelBtn) {
                    cancelBtn.addEventListener('click', hideModal);
                }

                modal.addEventListener('click', function(event) {
                    if (event.target === modal) {
                        hideModal();
                    }
                });
            }
        });
    </script>
</body>
</html>