<?php
// dashboard_admin.php
require_once 'config.php';

// Cek apakah pengguna sudah login dan perannya adalah admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["peran"] !== 'admin') {
    header("location: login.php");
    exit;
}

$nama_admin = htmlspecialchars($_SESSION["nama_lengkap"]);

// Logika untuk mengambil data spesifik admin bisa ditambahkan di sini

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title>Dashboard Admin - SoftLearn</title>
    <link rel="stylesheet" href="style.css?v=1.4">
</head>
<body>
    <div class="student-dashboard-header">
        <div class="student-profile">
            <div class="profile-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#00388E"><path d="M12 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 12 1Zm-5 4.5A2.5 2.5 0 0 1 9.5 3H11v1.5a2.5 2.5 0 0 1-5 0V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h-5v-.5ZM12 7a2.5 2.5 0 0 1 2.5 2.5v.5h5v-.5A2.5 2.5 0 0 1 17 7h-1.5a2.5 2.5 0 0 1-2.5-2.5V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h3.5a1.5 1.5 0 0 1 1.5 1.5v12a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 2 21.5v-12A1.5 1.5 0 0 1 3.5 8H7V7a2.5 2.5 0 0 1 2.5-2.5V3h1.5A2.5 2.5 0 0 1 12 5.5V7Z"/></svg>
            </div>
            <span class="student-name"><?php echo $nama_admin; ?> (Admin)</span>
        </div>
        <a href="#" id="logout-btn" class="menu-logout-link">Logout</a>
    </div>

    <div class="container admin-container">
        <main class="student-dashboard-main">
            <h2 class="dashboard-title">Panel Administrator</h2>

            <nav>
                <ul class="dashboard-nav-stacked">
                    <li>
                        <a href="admin_kelola_materi.php" class="nav-admin nav-kelola-materi">
                            <span class="nav-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="28" height="28" fill="#fff"><path d="M4 2.5A1.5 1.5 0 0 1 5.5 1h13A1.5 1.5 0 0 1 20 2.5v19A1.5 1.5 0 0 1 18.5 23h-13A1.5 1.5 0 0 1 4 21.5v-19ZM5.5 2c-.276 0-.5.224-.5.5v19c0 .276.224.5.5.5h13c.276 0 .5-.224.5-.5v-19c0-.276-.224-.5-.5-.5h-13ZM7 6h4a.5.5 0 1 1 0 1H7a.5.5 0 1 1 0-1Zm0 3h10a.5.5 0 1 1 0 1H7a.5.5 0 1 1 0-1Zm0 3h10a.5.5 0 1 1 0 1H7a.5.5 0 1 1 0-1Zm0 3h7a.5.5 0 1 1 0 1H7a.5.5 0 1 1 0-1Z"/></svg>
                            </span>
                            Kelola Materi
                        </a>
                    </li>
                    <li>
                        <a href="admin_kelola_kuis.php" class="nav-admin nav-kelola-kuis">
                            <span class="nav-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="28" height="28" fill="#fff"><path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H17.5A2.5 2.5 0 0 1 20 4.5v15A2.5 2.5 0 0 1 17.5 22H6.5A2.5 2.5 0 0 1 4 19.5v-15ZM6.5 3.5c-.276 0-.5.224-.5.5v15c0 .276.224.5.5.5H8V18a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v1.5h1.5c.276 0 .5-.224.5-.5v-15c0-.276-.224-.5-.5-.5H6.5Zm3.5 4H14a.5.5 0 1 1 0 1h-4a.5.5 0 1 1 0-1Zm0 3H14a.5.5 0 1 1 0 1h-4a.5.5 0 1 1 0-1Zm0 3H12a.5.5 0 1 1 0 1H10a.5.5 0 1 1 0-1Z"/></svg>
                            </span>
                            Kelola Kuis
                        </a>
                    </li>
                    <li>
                        <a href="admin_kelola_pengguna.php" class="nav-admin nav-kelola-pengguna">
                            <span class="nav-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="28" height="28" fill="#fff"><path d="M12 2a5 5 0 0 1 5 5v1.5a.5.5 0 0 0 .5.5h1.5a5 5 0 0 1 5 5v5.5a.5.5 0 0 1-1 0V14a4 4 0 0 0-4-4h-1.5a.5.5 0 0 1-.5-.5V8a4 4 0 0 0-8 0v1.5a.5.5 0 0 1-.5.5H7a4 4 0 0 0-4 4v1.5a.5.5 0 0 1-1 0V14a5 5 0 0 1 5-5h1.5a.5.5 0 0 0 .5-.5V7a5 5 0 0 1 5-5Zm-3 12.5a.5.5 0 0 0-1 0V16a4 4 0 0 0 4 4h1.5a.5.5 0 0 1 0 1H12a5 5 0 0 1-5-5v-1.5a.5.5 0 0 0-1 0V16a5 5 0 0 1 5 5h1.5a.5.5 0 0 0 0-1H12a4 4 0 0 0-4-4v-1.5Z"/></svg>
                            </span>
                            Kelola Pengguna
                        </a>
                    </li>
                     <li>
                        <a href="forum_komunikasi.php" class="nav-admin nav-kelola-forum">
                            <span class="nav-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="28" height="28" fill="#fff"><path d="M3 4.5A2.5 2.5 0 0 1 5.5 2h13A2.5 2.5 0 0 1 21 4.5v10A2.5 2.5 0 0 1 18.5 17H13.268l-2.81 2.341a.5.5 0 0 1-.716 0L6.92 17H5.5A2.5 2.5 0 0 1 3 14.5v-10ZM5.5 3c-.827 0-1.5.673-1.5 1.5v10c0 .827.673 1.5 1.5 1.5h1.88l2.662 2.218a1.5 1.5 0 0 0 2.116 0L14.88 16h1.62c.827 0 1.5-.673 1.5-1.5v-10c0-.827-.673-1.5-1.5-1.5h-13Z"/></svg>
                            </span>
                            Buka Forum
                        </a>
                    </li>
                </ul>
            </nav>
        </main>
    </div>

    <div class="site-footer">
        &copy; <?php echo date("Y"); ?> SoftLearn (Sistem Pembelajaran Online Interaktif untuk Kelas X SMK Jurusan RPL) - Kelompok 1 PTI 2023 B.
    </div>

    <!-- Modal Konfirmasi Logout -->
    <div id="logout-confirm-modal" class="modal-overlay modal-hidden">
        <div class="modal-content">
            <h3>Konfirmasi Logout</h3>
            <p>Apakah Anda yakin ingin keluar dari sesi ini?</p>
            <div class="modal-actions">
                <button id="logout-cancel-btn" class="btn btn-secondary">Batal</button>
                <a href="logout.php" id="logout-confirm-btn" class="btn btn-danger">Ya, Logout</a>
            </div>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const logoutLink = document.getElementById('logout-btn');
    const modal = document.getElementById('logout-confirm-modal');
    const cancelBtn = document.getElementById('logout-cancel-btn');

    if(logoutLink && modal) {
        logoutLink.addEventListener('click', function(event) {
            event.preventDefault(); // Mencegah link langsung redirect
            modal.classList.remove('modal-hidden');
        });

        function hideModal() {
            modal.classList.add('modal-hidden');
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', hideModal);
        }

        modal.addEventListener('click', function(event) {
            if (event.target === modal) {
                hideModal();
            }
        });
    }
});
</script>
</body>
</html>
