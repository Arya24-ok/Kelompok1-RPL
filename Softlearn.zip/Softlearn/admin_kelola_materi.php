<?php
// admin_kelola_materi.php
require_once 'config.php';

// Cek sesi admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["peran"] !== 'admin') {
    header("location: login.php");
    exit;
}

$nama_admin = htmlspecialchars($_SESSION["nama_lengkap"]);
$admin_id = $_SESSION["id_pengguna"];
$pesan_sukses = $pesan_error = "";

// Direktori untuk upload file materi
define('UPLOAD_DIR', 'uploads/materi/');
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

// Logika untuk menangani form (Tambah/Edit Materi)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_materi = $_POST['id_materi'] ?? null;
    $judul_materi = trim($_POST['judul_materi']);
    $deskripsi = trim($_POST['deskripsi']);
    $id_mapel = $_POST['id_mapel'];
    $tipe_konten = $_POST['tipe_konten'];
    $konten_materi = trim($_POST['konten_materi']);
    $file_path = $_POST['file_path_lama'] ?? ''; // Path file lama saat edit

    // Proses upload file jika ada file baru yang diupload
    if (isset($_FILES['file_materi']) && $_FILES['file_materi']['error'] == 0) {
        $file_name = time() . '_' . basename($_FILES["file_materi"]["name"]);
        $target_file = UPLOAD_DIR . $file_name;
        if (move_uploaded_file($_FILES["file_materi"]["tmp_name"], $target_file)) {
            $file_path = $target_file;
        } else {
            $pesan_error = "Maaf, terjadi kesalahan saat mengupload file.";
        }
    }

    if(empty($pesan_error)) {
        if ($id_materi) {
            // Logika Update
            $sql = "UPDATE Materi SET judul_materi=?, deskripsi=?, id_mapel=?, tipe_konten=?, konten_materi=?, file_path=? WHERE id_materi=?";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("ssisssi", $judul_materi, $deskripsi, $id_mapel, $tipe_konten, $konten_materi, $file_path, $id_materi);
        } else {
            // Logika Insert
            $sql = "INSERT INTO Materi (judul_materi, deskripsi, id_mapel, tipe_konten, konten_materi, file_path, id_uploader) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("ssisssi", $judul_materi, $deskripsi, $id_mapel, $tipe_konten, $konten_materi, $file_path, $admin_id);
        }

        if ($stmt->execute()) {
            $pesan_sukses = "Materi berhasil disimpan.";
        } else {
            $pesan_error = "Terjadi kesalahan: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Logika untuk menghapus materi
if (isset($_GET['hapus'])) {
    $id_hapus = intval($_GET['hapus']);
    // Optional: Hapus file fisik dari server
    $sql_getfile = "SELECT file_path FROM Materi WHERE id_materi = ?";
    $stmt_getfile = $mysqli->prepare($sql_getfile);
    $stmt_getfile->bind_param("i", $id_hapus);
    $stmt_getfile->execute();
    $result_file = $stmt_getfile->get_result();
    if($row = $result_file->fetch_assoc()){
        if(!empty($row['file_path']) && file_exists($row['file_path'])){
            unlink($row['file_path']);
        }
    }
    $stmt_getfile->close();
    
    // Hapus record dari database
    $sql_hapus = "DELETE FROM Materi WHERE id_materi = ?";
    $stmt_hapus = $mysqli->prepare($sql_hapus);
    $stmt_hapus->bind_param("i", $id_hapus);
    if ($stmt_hapus->execute()) {
        $pesan_sukses = "Materi berhasil dihapus.";
    } else {
        $pesan_error = "Gagal menghapus materi.";
    }
    $stmt_hapus->close();
}


// Ambil data untuk form edit
$materi_edit = null;
if (isset($_GET['edit'])) {
    $id_edit = intval($_GET['edit']);
    $sql_edit = "SELECT * FROM Materi WHERE id_materi = ?";
    $stmt_edit = $mysqli->prepare($sql_edit);
    $stmt_edit->bind_param("i", $id_edit);
    $stmt_edit->execute();
    $result_edit = $stmt_edit->get_result();
    $materi_edit = $result_edit->fetch_assoc();
    $stmt_edit->close();
}

// Ambil daftar materi dan mata pelajaran
$daftar_materi = $mysqli->query("SELECT m.*, mp.nama_mapel FROM Materi m JOIN Mata_Pelajaran mp ON m.id_mapel = mp.id_mapel ORDER BY m.tanggal_upload DESC");
$daftar_mapel = $mysqli->query("SELECT * FROM Mata_Pelajaran ORDER BY nama_mapel");

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title>Kelola Materi - Admin SoftLearn</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="student-dashboard-header">
        <div class="student-profile">
            <div class="profile-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#00388E"><path d="M12 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 12 1Zm-5 4.5A2.5 2.5 0 0 1 9.5 3H11v1.5a2.5 2.5 0 0 1-5 0V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h-5v-.5ZM12 7a2.5 2.5 0 0 1 2.5 2.5v.5h5v-.5A2.5 2.5 0 0 1 17 7h-1.5a2.5 2.5 0 0 1-2.5-2.5V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h3.5a1.5 1.5 0 0 1 1.5 1.5v12a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 2 21.5v-12A1.5 1.5 0 0 1 3.5 8H7V7a2.5 2.5 0 0 1 2.5-2.5V3h1.5A2.5 2.5 0 0 1 12 5.5V7Z"/></svg>
            </div>
            <span class="student-name"><?php echo $nama_admin; ?> (Admin)</span>
        </div>
        <a href="#" id="logout-btn" class="menu-logout-link">Logout</a>
    </div>

    <div class="container">
        <main class="student-dashboard-main page-content">
            <div class="page-header">
                <a href="dashboard_admin.php" class="back-button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M10.8284 12.0007L15.7782 16.9504L14.364 18.3646L8 12.0007L14.364 5.63672L15.7782 7.05093L10.8284 12.0007Z"></path></svg>
                </a>
                <h1 class="page-title-text">Kelola Materi</h1>
            </div>

            <?php if($pesan_sukses): ?><div class="success-message"><?php echo $pesan_sukses; ?></div><?php endif; ?>
            <?php if($pesan_error): ?><div class="error-message"><?php echo $pesan_error; ?></div><?php endif; ?>

            <div class="admin-form-container">
                <h3><?php echo $materi_edit ? 'Edit Materi' : 'Tambah Materi Baru'; ?></h3>
                <form action="admin_kelola_materi.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id_materi" value="<?php echo $materi_edit['id_materi'] ?? ''; ?>">
                    <div class="form-group">
                        <label for="judul_materi">Judul Materi</label>
                        <input type="text" id="judul_materi" name="judul_materi" value="<?php echo htmlspecialchars($materi_edit['judul_materi'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="id_mapel">Mata Pelajaran</label>
                        <select id="id_mapel" name="id_mapel" required>
                            <option value="">-- Pilih Mata Pelajaran --</option>
                            <?php $daftar_mapel->data_seek(0); // Reset pointer hasil query ?>
                            <?php while($mapel = $daftar_mapel->fetch_assoc()): ?>
                                <option value="<?php echo $mapel['id_mapel']; ?>" <?php echo (isset($materi_edit) && $materi_edit['id_mapel'] == $mapel['id_mapel']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($mapel['nama_mapel']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="deskripsi">Deskripsi</label>
                        <textarea id="deskripsi" name="deskripsi" rows="3"><?php echo htmlspecialchars($materi_edit['deskripsi'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="tipe_konten">Tipe Konten</label>
                        <select id="tipe_konten" name="tipe_konten" required>
                            <option value="teks" <?php echo (isset($materi_edit) && $materi_edit['tipe_konten'] == 'teks') ? 'selected' : ''; ?>>Teks</option>
                            <option value="file_pdf" <?php echo (isset($materi_edit) && $materi_edit['tipe_konten'] == 'file_pdf') ? 'selected' : ''; ?>>File PDF</option>
                            <option value="video_embed" <?php echo (isset($materi_edit) && $materi_edit['tipe_konten'] == 'video_embed') ? 'selected' : ''; ?>>Video Embed</option>
                            <option value="link_eksternal" <?php echo (isset($materi_edit) && $materi_edit['tipe_konten'] == 'link_eksternal') ? 'selected' : ''; ?>>Link Eksternal</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="konten_materi">Konten (untuk Teks, Video Embed, atau Link)</label>
                        <textarea id="konten_materi" name="konten_materi" rows="5" placeholder="Isi teks, kode embed video, atau URL di sini..."><?php echo htmlspecialchars($materi_edit['konten_materi'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="file_materi">File (untuk tipe File PDF)</label>
                        <input type="file" id="file_materi" name="file_materi" accept=".pdf">
                        <?php if (isset($materi_edit) && !empty($materi_edit['file_path'])): ?>
                            <p>File saat ini: <a href="<?php echo htmlspecialchars($materi_edit['file_path']); ?>" target="_blank"><?php echo basename($materi_edit['file_path']); ?></a></p>
                            <input type="hidden" name="file_path_lama" value="<?php echo htmlspecialchars($materi_edit['file_path']); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn"><?php echo $materi_edit ? 'Update Materi' : 'Simpan Materi'; ?></button>
                        <?php if ($materi_edit): ?>
                            <a href="admin_kelola_materi.php" class="btn btn-secondary">Batal Edit</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="admin-table-container">
                <h3>Daftar Materi yang Ada</h3>
                <div class="table-wrapper">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Judul</th>
                                <th>Mata Pelajaran</th>
                                <th>Tipe</th>
                                <th>Tanggal Upload</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($daftar_materi->num_rows > 0): ?>
                                <?php $daftar_materi->data_seek(0); // Reset pointer hasil query ?>
                                <?php while($materi = $daftar_materi->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($materi['judul_materi']); ?></td>
                                    <td><?php echo htmlspecialchars($materi['nama_mapel']); ?></td>
                                    <td><?php echo htmlspecialchars($materi['tipe_konten']); ?></td>
                                    <td><?php echo date('d M Y', strtotime($materi['tanggal_upload'])); ?></td>
                                    <td class="action-buttons">
                                        <a href="admin_kelola_materi.php?edit=<?php echo $materi['id_materi']; ?>" class="btn-edit">Edit</a>
                                        <a href="admin_kelola_materi.php?hapus=<?php echo $materi['id_materi']; ?>" class="btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus materi ini?');">Hapus</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5">Belum ada materi.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>
    </div>

    <div id="logout-confirm-modal" class="modal-overlay modal-hidden">
        <div class="modal-content">
            <h3>Konfirmasi Logout</h3>
            <p>Apakah Anda yakin ingin keluar dari sesi ini?</p>
            <div class="modal-actions">
                <button id="logout-cancel-btn" class="btn btn-secondary">Batal</button>
                <a href="logout.php" id="logout-confirm-btn" class="btn btn-danger">Ya, Logout</a>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const logoutLink = document.getElementById('logout-btn');
        const modal = document.getElementById('logout-confirm-modal');
        const cancelBtn = document.getElementById('logout-cancel-btn');

        if(logoutLink && modal) {
            logoutLink.addEventListener('click', function(event) {
                event.preventDefault(); // Mencegah link langsung redirect
                modal.classList.remove('modal-hidden');
            });

            function hideModal() {
                modal.classList.add('modal-hidden');
            }

            if (cancelBtn) {
                cancelBtn.addEventListener('click', hideModal);
            }

            modal.addEventListener('click', function(event) {
                if (event.target === modal) {
                    hideModal();
                }
            });
        }
    });
    </script>
</body>
</html>