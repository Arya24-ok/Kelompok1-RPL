<?php
// api_kuis.php
require_once 'config.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    case 'start':
        if (isset($_GET['id_kuis'])) {
            $id_kuis = intval($_GET['id_kuis']);
            $stmt = $mysqli->prepare("SELECT id_pertanyaan, teks_pertanyaan, opsi_jawaban_json, poin FROM Pertanyaan_Kuis WHERE id_kuis = ? ORDER BY RAND()");
            $stmt->bind_param("i", $id_kuis);
            $stmt->execute();
            $result = $stmt->get_result();
            $questions = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            
            echo json_encode(['status' => 'success', 'questions' => $questions]);
        }
        break;

    case 'submit':
        if (isset($_POST['id_kuis'], $_POST['id_siswa'], $_POST['id_pertanyaan'], $_POST['jawaban'])) {
            $id_kuis = intval($_POST['id_kuis']);
            $id_siswa = intval($_POST['id_siswa']);
            $id_pertanyaan = intval($_POST['id_pertanyaan']);
            $jawaban_siswa = trim($_POST['jawaban']);

            $stmt_key = $mysqli->prepare("SELECT kunci_jawaban, poin FROM Pertanyaan_Kuis WHERE id_pertanyaan = ?");
            $stmt_key->bind_param("i", $id_pertanyaan);
            $stmt_key->execute();
            $result_key = $stmt_key->get_result()->fetch_assoc();
            $kunci_jawaban = $result_key['kunci_jawaban'];
            $poin = $result_key['poin'];
            $stmt_key->close();

            $is_correct = ($jawaban_siswa == $kunci_jawaban);
            $skor_diperoleh = $is_correct ? $poin : 0;
            
            $stmt_save = $mysqli->prepare("INSERT INTO Jawaban_Siswa (id_kuis, id_siswa, id_pertanyaan, jawaban_siswa, skor_diperoleh) VALUES (?, ?, ?, ?, ?)");
            $stmt_save->bind_param("iiisi", $id_kuis, $id_siswa, $id_pertanyaan, $jawaban_siswa, $skor_diperoleh);
            $stmt_save->execute();
            $stmt_save->close();

            echo json_encode([
                'status' => 'success',
                'correct' => $is_correct,
                'correct_answer' => $kunci_jawaban 
            ]);
        }
        break;
        
    case 'finish_quiz':
        // Aksi baru untuk menyimpan hasil akhir
        if (isset($_POST['id_kuis'], $_POST['id_siswa'], $_POST['total_skor'])) {
            $id_kuis = intval($_POST['id_kuis']);
            $id_siswa = intval($_POST['id_siswa']);
            $total_skor = intval($_POST['total_skor']);

            // Gunakan ON DUPLICATE KEY UPDATE untuk menangani jika siswa mengulang kuis
            // Ini memerlukan UNIQUE KEY pada (id_kuis, id_siswa) di tabel Hasil_Kuis_Siswa
            $sql = "
                INSERT INTO Hasil_Kuis_Siswa (id_kuis, id_siswa, total_skor, waktu_mulai, waktu_selesai, status) 
                VALUES (?, ?, ?, NOW(), NOW(), 'selesai')
                ON DUPLICATE KEY UPDATE 
                total_skor = VALUES(total_skor), waktu_selesai = NOW()
            ";
            
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("iii", $id_kuis, $id_siswa, $total_skor);
            $stmt->execute();
            $stmt->close();
            
            echo json_encode(['status' => 'success', 'message' => 'Hasil kuis berhasil disimpan.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Data tidak lengkap untuk menyimpan hasil.']);
        }
        break;
        
    default:
        echo json_encode(['status' => 'error', 'message' => 'Aksi tidak valid.']);
        break;
}

$mysqli->close();
?>
