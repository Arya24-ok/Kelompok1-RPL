<?php
// login.php

// Memasukkan file konfigurasi
require_once 'config.php';

// Inisialisasi variabel untuk pesan error
$error_message = '';

// Cek apakah pengguna sudah login, jika iya, arahkan ke dashboard yang sesuai
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    if ($_SESSION['peran'] == 'admin') {
        header("location: dashboard_admin.php");
        exit;
    } elseif ($_SESSION['peran'] == 'siswa') {
        header("location: dashboard_siswa.php");
        exit;
    }
}

// Proses data form ketika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validasi username
    if (empty(trim($_POST["username"]))) {
        $error_message = "Harap isi username.";
    } else {
        $username = sanitize_input(trim($_POST["username"]));
    }

    // Validasi password
    if (empty(trim($_POST["password"]))) {
        if (empty($error_message)) { // Hanya set error jika belum ada error sebelumnya
            $error_message = "Harap isi password.";
        }
    } else {
        $password = trim($_POST["password"]); // Password tidak di-sanitize dengan htmlspecialchars
    }

    // Jika tidak ada error validasi input
    if (empty($error_message)) {
        // Siapkan statement SELECT
        $sql = "SELECT id_pengguna, username, password_hash, peran, nama_lengkap FROM Pengguna WHERE username = ?";

        if ($stmt = $mysqli->prepare($sql)) {
            // Bind variabel ke prepared statement sebagai parameter
            $stmt->bind_param("s", $param_username);

            // Set parameter
            $param_username = $username;

            // Coba eksekusi prepared statement
            if ($stmt->execute()) {
                // Simpan hasil
                $stmt->store_result();

                // Cek jika username ada, lalu verifikasi password
                if ($stmt->num_rows == 1) {
                    // Bind hasil variabel
                    $stmt->bind_result($id_pengguna, $db_username, $hashed_password, $peran, $nama_lengkap);
                    if ($stmt->fetch()) {
                        if (password_verify($password, $hashed_password)) {
                            // Password benar, mulai sesi baru

                            session_unset();
                            session_destroy();
                            session_start(); 

                            $_SESSION["loggedin"] = true;
                            $_SESSION["id_pengguna"] = $id_pengguna;
                            $_SESSION["username"] = $db_username;
                            $_SESSION["peran"] = $peran;
                            $_SESSION["nama_lengkap"] = $nama_lengkap;

                            if ($peran == 'admin') {
                                header("location: dashboard_admin.php");
                                exit;
                            } elseif ($peran == 'siswa') {
                                header("location: dashboard_siswa.php");
                                exit;
                            } else {
                                $error_message = "Peran pengguna tidak dikenal.";
                            }
                        } else {
                            $error_message = "Username atau password salah.";
                        }
                    }
                } else {
                    $error_message = "Username atau password salah.";
                }
            } else {
                $error_message = "Oops! Terjadi kesalahan. Silakan coba lagi nanti.";
            }
            $stmt->close();
        } else {
            $error_message = "Oops! Terjadi kesalahan pada persiapan statement. Silakan coba lagi nanti.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title>Login - SoftLearn</title>
    <link rel="stylesheet" href="style.css?v=1.5">
</head>
<body class="login-page"> <!-- Menambahkan kelas 'login-page' untuk penataan tengah -->
    <div class="login-page-wrapper">
        <div class="login-branding">
            <div class="welcome-text">Selamat Datang di</div>
            <div class="logo-text">SoftLearn.</div>
        </div>

        <div class="login-container">
            <h2 class="login-prompt">Login Dulu Yuk!</h2>

            <?php
            if (!empty($error_message)) {
                echo '<div class="error-message">' . htmlspecialchars($error_message) . '</div>';
            }
            ?>

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" novalidate>
                <div class="form-group">
                    <label for="username">Username</label> 
                    <input type="text" name="username" id="username" required placeholder="Username" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label for="password">Password</label> 
                    <input type="password" name="password" id="password" required placeholder="Password">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn">Login</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Footer Universal -->
    <div class="site-footer">
        &copy; <?php echo date("Y"); ?> SoftLearn (Sistem Pembelajaran Online Interaktif untuk Kelas X SMK Jurusan RPL)- Kelompok 1 PTI 2023 B.
    </div>

</body>
</html>
