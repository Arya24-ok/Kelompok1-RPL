<?php
// dashboard_siswa.php
require_once 'config.php';

// Cek apakah pengguna sudah login dan perannya adalah siswa
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["peran"] !== 'siswa') {
    header("location: login.php");
    exit;
}

$nama_siswa = htmlspecialchars($_SESSION["nama_lengkap"]);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title>Dashboard Siswa - SoftLearn</title>
    <link rel="stylesheet" href="style.css?v=1.3">
    </head>
<body>
    <div class="student-dashboard-header">
        <div class="student-profile">
            <div class="profile-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#00388E"><path d="M12 2.5a.5.5 0 0 1 .5.5v1.255a7 7 0 0 1 5.422 5.422H19.25a.5.5 0 0 1 .5.5v2.586a.5.5 0 0 1-.146.353l-1.855 1.856a.5.5 0 0 1-.353.146H7.08a.5.5 0 0 1-.353-.146L4.872 12.62a.5.5 0 0 1-.146-.353V9.681a.5.5 0 0 1 .5-.5h1.327A7 7 0 0 1 11.5 4.255V3a.5.5 0 0 1 .5-.5ZM12 5a6 6 0 0 0-5.173 2.827A5.999 5.999 0 0 0 12 13a5.999 5.999 0 0 0 5.173-5.173A6 6 0 0 0 12 5Zm0 1.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"/><path d="M4.5 15.25a.5.5 0 0 1 .5-.5h14a.5.5 0 0 1 .5.5v2.017c0 .858-.338 1.674-1.007 2.343C17.08 20.919 14.89 21.5 12 21.5s-5.08-.581-6.493-1.89C4.838 18.94 4.5 18.125 4.5 17.267v-2.017Z"/></svg>
            </div>
            <span class="student-name"><?php echo $nama_siswa; ?></span>
        </div>
        <!-- Link Logout sekarang akan memicu modal, bukan direct link -->
        <a href="#" id="logout-btn" class="menu-logout-link">Logout</a>
    </div>

    <div class="container">
        <main class="student-dashboard-main">
            <h2 class="dashboard-title">Mau Ngapain Hari Ini? 🤔</h2>
            <nav>
                <ul class="dashboard-nav-stacked">
                    <li>
                        <a href="materi_siswa.php" class="nav-materi">
                            <span class="nav-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="28" height="28" fill="#fff"><path d="M4 2.5A1.5 1.5 0 0 1 5.5 1h13A1.5 1.5 0 0 1 20 2.5v19A1.5 1.5 0 0 1 18.5 23h-13A1.5 1.5 0 0 1 4 21.5v-19ZM5.5 2c-.276 0-.5.224-.5.5v19c0 .276.224.5.5.5h13c.276 0 .5-.224.5-.5v-19c0-.276-.224-.5-.5-.5h-13ZM7 6h4a.5.5 0 1 1 0 1H7a.5.5 0 1 1 0-1Zm0 3h10a.5.5 0 1 1 0 1H7a.5.5 0 1 1 0-1Zm0 3h10a.5.5 0 1 1 0 1H7a.5.5 0 1 1 0-1Zm0 3h7a.5.5 0 1 1 0 1H7a.5.5 0 1 1 0-1Z"/></svg>
                            </span>
                            Materi
                        </a>
                    </li>
                    <li>
                        <a href="kuis_siswa.php" class="nav-kuis">
                            <span class="nav-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="28" height="28" fill="#fff"><path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H17.5A2.5 2.5 0 0 1 20 4.5v15A2.5 2.5 0 0 1 17.5 22H6.5A2.5 2.5 0 0 1 4 19.5v-15ZM6.5 3.5c-.276 0-.5.224-.5.5v15c0 .276.224.5.5.5H8V18a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v1.5h1.5c.276 0 .5-.224.5-.5v-15c0-.276-.224-.5-.5-.5H6.5Zm3.5 4H14a.5.5 0 1 1 0 1h-4a.5.5 0 1 1 0-1Zm0 3H14a.5.5 0 1 1 0 1h-4a.5.5 0 1 1 0-1Zm0 3H12a.5.5 0 1 1 0 1H10a.5.5 0 1 1 0-1Z"/></svg>
                            </span>
                            Kuis
                        </a>
                    </li>
                    <li>
                        <a href="forum_komunikasi.php" class="nav-forum">
                            <span class="nav-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="28" height="28" fill="#fff"><path d="M3 4.5A2.5 2.5 0 0 1 5.5 2h13A2.5 2.5 0 0 1 21 4.5v10A2.5 2.5 0 0 1 18.5 17H13.268l-2.81 2.341a.5.5 0 0 1-.716 0L6.92 17H5.5A2.5 2.5 0 0 1 3 14.5v-10ZM5.5 3c-.827 0-1.5.673-1.5 1.5v10c0 .827.673 1.5 1.5 1.5h1.88l2.662 2.218a1.5 1.5 0 0 0 2.116 0L14.88 16h1.62c.827 0 1.5-.673 1.5-1.5v-10c0-.827-.673-1.5-1.5-1.5h-13Z"/></svg>
                            </span>
                            Forum Diskusi
                        </a>
                    </li>
                </ul>
            </nav>
        </main>
    </div>
    
    <div class="site-footer">
        &copy; <?php echo date("Y"); ?> SoftLearn (Sistem Pembelajaran Online Interaktif untuk Kelas X SMK Jurusan RPL) - Kelompok 1 PTI 2023 B.
    </div>

    <!-- Modal Konfirmasi Logout -->
    <div id="logout-confirm-modal" class="modal-overlay modal-hidden">
        <div class="modal-content">
            <h3>Konfirmasi Logout</h3>
            <p>Apakah Anda yakin ingin keluar dari sesi ini?</p>
            <div class="modal-actions">
                <button id="logout-cancel-btn" class="btn btn-secondary">Batal</button>
                <a href="logout.php" id="logout-confirm-btn" class="btn btn-danger">Ya, Logout</a>
            </div>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const logoutLink = document.getElementById('logout-btn');
    const modal = document.getElementById('logout-confirm-modal');
    const cancelBtn = document.getElementById('logout-cancel-btn');

    if(logoutLink && modal) {
        logoutLink.addEventListener('click', function(event) {
            event.preventDefault(); // Mencegah link langsung redirect
            modal.classList.remove('modal-hidden');
        });

        // Fungsi untuk menyembunyikan modal
        function hideModal() {
            modal.classList.add('modal-hidden');
        }

        // Sembunyikan modal saat tombol batal diklik
        if (cancelBtn) {
            cancelBtn.addEventListener('click', hideModal);
        }

        // Sembunyikan modal saat area overlay diklik
        modal.addEventListener('click', function(event) {
            if (event.target === modal) {
                hideModal();
            }
        });
    }
});
</script>
</body>
</html>
