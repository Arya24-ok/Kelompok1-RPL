<?php
// admin_edit_kuis.php
require_once 'config.php';

// Cek sesi admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["peran"] !== 'admin') {
    header("location: login.php");
    exit;
}

// Pastikan ID kuis ada di URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("location: admin_kelola_kuis.php");
    exit;
}

$id_kuis = intval($_GET['id']);
$nama_admin = htmlspecialchars($_SESSION["nama_lengkap"]);
$pesan_sukses = $pesan_error = "";

// Logika untuk UPDATE kuis dan pertanyaannya
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_kuis'])) {
    if (empty($_POST['judul_kuis']) || empty($_POST['id_mapel'])) {
        $pesan_error = "Judul kuis dan mata pelajaran harus diisi.";
    } else {
        $mysqli->begin_transaction();
        try {
            // 1. Update detail kuis utama
            $judul_kuis = $_POST['judul_kuis'];
            $id_mapel = $_POST['id_mapel'];
            $level = $_POST['level_kesulitan'];
            $deskripsi = $_POST['deskripsi'];
            $waktu_pengerjaan = $_POST['waktu_pengerjaan_menit'];

            $stmt_kuis = $mysqli->prepare("UPDATE Kuis SET id_mapel=?, judul_kuis=?, deskripsi=?, level_kesulitan=?, waktu_pengerjaan_menit=? WHERE id_kuis=?");
            $stmt_kuis->bind_param("isssii", $id_mapel, $judul_kuis, $deskripsi, $level, $waktu_pengerjaan, $id_kuis);
            $stmt_kuis->execute();
            $stmt_kuis->close();

            // 2. Proses pertanyaan: update, insert, atau delete
            $submitted_ids = []; // Tampung ID pertanyaan yang ada di form
            $stmt_update_pertanyaan = $mysqli->prepare("UPDATE Pertanyaan_Kuis SET teks_pertanyaan=?, opsi_jawaban_json=?, kunci_jawaban=?, poin=? WHERE id_pertanyaan=?");
            $stmt_insert_pertanyaan = $mysqli->prepare("INSERT INTO Pertanyaan_Kuis (id_kuis, teks_pertanyaan, opsi_jawaban_json, kunci_jawaban, poin) VALUES (?, ?, ?, ?, ?)");

            if (isset($_POST['pertanyaan'])) {
                foreach ($_POST['pertanyaan'] as $index => $data) {
                    if (empty($data['teks']) || empty($data['opsi_a']) || empty($data['opsi_b']) || empty($data['opsi_c']) || empty($data['opsi_d']) || empty($data['kunci'])) {
                        throw new Exception("Semua field pada salah satu pertanyaan harus diisi.");
                    }
                    $teks = $data['teks'];
                    $kunci_jawaban = $data['kunci'];
                    $poin = $data['poin'];
                    $opsi = ['A' => $data['opsi_a'], 'B' => $data['opsi_b'], 'C' => $data['opsi_c'], 'D' => $data['opsi_d']];
                    $opsi_json = json_encode($opsi);

                    if (!empty($data['id_pertanyaan'])) {
                        // Ini pertanyaan LAMA (UPDATE)
                        $id_pertanyaan = $data['id_pertanyaan'];
                        $stmt_update_pertanyaan->bind_param("sssii", $teks, $opsi_json, $kunci_jawaban, $poin, $id_pertanyaan);
                        $stmt_update_pertanyaan->execute();
                        $submitted_ids[] = $id_pertanyaan;
                    } else {
                        // Ini pertanyaan BARU (INSERT)
                        $stmt_insert_pertanyaan->bind_param("isssi", $id_kuis, $teks, $opsi_json, $kunci_jawaban, $poin);
                        $stmt_insert_pertanyaan->execute();
                    }
                }
            }
            $stmt_update_pertanyaan->close();
            $stmt_insert_pertanyaan->close();

            // 3. Hapus pertanyaan yang tidak ada lagi di form
            $result_existing = $mysqli->query("SELECT id_pertanyaan FROM Pertanyaan_Kuis WHERE id_kuis = $id_kuis");
            $existing_ids = [];
            while ($row = $result_existing->fetch_assoc()) {
                $existing_ids[] = $row['id_pertanyaan'];
            }
            $ids_to_delete = array_diff($existing_ids, $submitted_ids);
            if (!empty($ids_to_delete)) {
                $delete_list = implode(',', $ids_to_delete);
                $mysqli->query("DELETE FROM Pertanyaan_Kuis WHERE id_pertanyaan IN ($delete_list)");
            }

            $mysqli->commit();
            $_SESSION['pesan_sukses_redirect'] = "Kuis berhasil diperbarui.";
            header("Location: admin_kelola_kuis.php");
            exit;

        } catch (Exception $e) {
            $mysqli->rollback();
            $pesan_error = "Gagal memperbarui kuis: " . $e->getMessage();
        }
    }
}


// Ambil data kuis dan pertanyaan untuk ditampilkan di form
$kuis_edit = null;
$pertanyaan_edit = [];
$stmt_kuis = $mysqli->prepare("SELECT * FROM Kuis WHERE id_kuis = ?");
$stmt_kuis->bind_param("i", $id_kuis);
$stmt_kuis->execute();
$result_kuis = $stmt_kuis->get_result();
if ($result_kuis->num_rows == 1) {
    $kuis_edit = $result_kuis->fetch_assoc();
    $stmt_kuis->close();

    $stmt_pertanyaan = $mysqli->prepare("SELECT * FROM Pertanyaan_Kuis WHERE id_kuis = ? ORDER BY id_pertanyaan ASC");
    $stmt_pertanyaan->bind_param("i", $id_kuis);
    $stmt_pertanyaan->execute();
    $result_pertanyaan = $stmt_pertanyaan->get_result();
    while($row = $result_pertanyaan->fetch_assoc()){
        $pertanyaan_edit[] = $row;
    }
    $stmt_pertanyaan->close();
} else {
    header("location: admin_kelola_kuis.php"); exit;
}

$daftar_mapel = $mysqli->query("SELECT * FROM Mata_Pelajaran ORDER BY nama_mapel");

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo.png" type="image/x-icon">
    <title>Edit Kuis - Admin SoftLearn</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="student-dashboard-header">
        <div class="student-profile">
            <div class="profile-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#00388E"><path d="M12 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 12 1Zm-5 4.5A2.5 2.5 0 0 1 9.5 3H11v1.5a2.5 2.5 0 0 1-5 0V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h-5v-.5ZM12 7a2.5 2.5 0 0 1 2.5 2.5v.5h5v-.5A2.5 2.5 0 0 1 17 7h-1.5a2.5 2.5 0 0 1-2.5-2.5V3h1.5a2.5 2.5 0 0 1 2.5 2.5v.5h3.5a1.5 1.5 0 0 1 1.5 1.5v12a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 2 21.5v-12A1.5 1.5 0 0 1 3.5 8H7V7a2.5 2.5 0 0 1 2.5-2.5V3h1.5A2.5 2.5 0 0 1 12 5.5V7Z"/></svg></div>
            <span class="student-name"><?php echo $nama_admin; ?> (Admin)</span>
        </div>
        <a href="#" id="logout-btn" class="menu-logout-link">Logout</a>
    </div>

    <div class="container admin-container">
        <main class="student-dashboard-main page-content">
            <div class="page-header">
                <a href="admin_kelola_kuis.php" class="back-button"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M10.8284 12.0007L15.7782 16.9504L14.364 18.3646L8 12.0007L14.364 5.63672L15.7782 7.05093L10.8284 12.0007Z"></path></svg></a>
                <h1 class="page-title-text">Edit Kuis</h1>
            </div>

            <?php if($pesan_sukses): ?><div class="success-message"><?php echo $pesan_sukses; ?></div><?php endif; ?>
            <?php if($pesan_error): ?><div class="error-message"><?php echo $pesan_error; ?></div><?php endif; ?>

            <form action="admin_edit_kuis.php?id=<?php echo $id_kuis; ?>" method="post" id="quiz-form">
                <div class="admin-form-container">
                    <h3>Detail Kuis</h3>
                    <div class="form-group"><label for="judul_kuis">Judul Kuis</label><input type="text" id="judul_kuis" name="judul_kuis" required value="<?php echo htmlspecialchars($kuis_edit['judul_kuis']); ?>"></div>
                    <div class="form-group"><label for="id_mapel">Mata Pelajaran</label>
                        <select id="id_mapel" name="id_mapel" required>
                            <option value="">-- Pilih Mata Pelajaran --</option>
                            <?php if ($daftar_mapel->num_rows > 0): ?><?php $daftar_mapel->data_seek(0); ?><?php while($mapel = $daftar_mapel->fetch_assoc()): ?>
                                <option value="<?php echo $mapel['id_mapel']; ?>" <?php echo ($kuis_edit['id_mapel'] == $mapel['id_mapel']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($mapel['nama_mapel']); ?>
                                </option>
                            <?php endwhile; ?><?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group"><label for="level_kesulitan">Level Kesulitan</label>
                        <select id="level_kesulitan" name="level_kesulitan" required>
                            <option value="Beginner" <?php echo ($kuis_edit['level_kesulitan'] == 'Beginner') ? 'selected' : ''; ?>>Beginner</option>
                            <option value="Intermediate" <?php echo ($kuis_edit['level_kesulitan'] == 'Intermediate') ? 'selected' : ''; ?>>Intermediate</option>
                            <option value="Advanced" <?php echo ($kuis_edit['level_kesulitan'] == 'Advanced') ? 'selected' : ''; ?>>Advanced</option>
                            <option value="Expert" <?php echo ($kuis_edit['level_kesulitan'] == 'Expert') ? 'selected' : ''; ?>>Expert</option>
                        </select>
                    </div>
                    <div class="form-group"><label for="waktu_pengerjaan_menit">Durasi Kuis (menit)</label><input type="number" id="waktu_pengerjaan_menit" name="waktu_pengerjaan_menit" required min="1" value="<?php echo htmlspecialchars($kuis_edit['waktu_pengerjaan_menit']); ?>"></div>
                    <div class="form-group"><label for="deskripsi">Deskripsi Singkat (Opsional)</label><textarea id="deskripsi" name="deskripsi" rows="3"><?php echo htmlspecialchars($kuis_edit['deskripsi']); ?></textarea></div>
                </div>

                <div class="admin-form-container">
                    <h3>Pertanyaan Kuis</h3>
                    <div id="question-editor-container">
                        <?php foreach($pertanyaan_edit as $index => $p): ?>
                            <?php $opsi = json_decode($p['opsi_jawaban_json'], true); ?>
                            <div class="question-block">
                                <input type="hidden" name="pertanyaan[<?php echo $index; ?>][id_pertanyaan]" value="<?php echo $p['id_pertanyaan']; ?>">
                                <div class="question-header">
                                    <h4>Pertanyaan #<?php echo $index + 1; ?></h4>
                                    <div class="form-group-inline"><label>Poin</label><input type="number" class="poin-input" name="pertanyaan[<?php echo $index; ?>][poin]" value="<?php echo $p['poin']; ?>" min="1" required></div>
                                    <button type="button" class="btn-delete-question">&times;</button>
                                </div>
                                <div class="form-group"><label>Teks Pertanyaan</label><textarea name="pertanyaan[<?php echo $index; ?>][teks]" rows="3" required><?php echo htmlspecialchars($p['teks_pertanyaan']); ?></textarea></div>
                                <div class="options-grid">
                                    <div class="option-input-group"><input type="radio" name="pertanyaan[<?php echo $index; ?>][kunci]" value="A" required <?php echo ($p['kunci_jawaban'] == 'A') ? 'checked' : ''; ?>><label>A</label><input type="text" name="pertanyaan[<?php echo $index; ?>][opsi_a]" required value="<?php echo htmlspecialchars($opsi['A']); ?>"></div>
                                    <div class="option-input-group"><input type="radio" name="pertanyaan[<?php echo $index; ?>][kunci]" value="B" <?php echo ($p['kunci_jawaban'] == 'B') ? 'checked' : ''; ?>><label>B</label><input type="text" name="pertanyaan[<?php echo $index; ?>][opsi_b]" required value="<?php echo htmlspecialchars($opsi['B']); ?>"></div>
                                    <div class="option-input-group"><input type="radio" name="pertanyaan[<?php echo $index; ?>][kunci]" value="C" <?php echo ($p['kunci_jawaban'] == 'C') ? 'checked' : ''; ?>><label>C</label><input type="text" name="pertanyaan[<?php echo $index; ?>][opsi_c]" required value="<?php echo htmlspecialchars($opsi['C']); ?>"></div>
                                    <div class="option-input-group"><input type="radio" name="pertanyaan[<?php echo $index; ?>][kunci]" value="D" <?php echo ($p['kunci_jawaban'] == 'D') ? 'checked' : ''; ?>><label>D</label><input type="text" name="pertanyaan[<?php echo $index; ?>][opsi_d]" required value="<?php echo htmlspecialchars($opsi['D']); ?>"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button type="button" id="add-question-btn" class="btn btn-secondary">Tambah Pertanyaan Baru</button>
                </div>
                
                <div class="form-actions">
                    <button type="submit" name="update_kuis" class="btn">Update Kuis dan Pertanyaan</button>
                </div>
            </form>
        </main>
    </div>

    <div id="logout-confirm-modal" class="modal-overlay modal-hidden"><div class="modal-content"><h3>Konfirmasi Logout</h3><p>Apakah Anda yakin ingin keluar dari sesi ini?</p><div class="modal-actions"><button id="logout-cancel-btn" class="btn btn-secondary">Batal</button><a href="logout.php" id="logout-confirm-btn" class="btn btn-danger">Ya, Logout</a></div></div></div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Script Logout
    const logoutLink = document.getElementById('logout-btn');
    const modal = document.getElementById('logout-confirm-modal');
    const cancelBtn = document.getElementById('logout-cancel-btn');
    if(logoutLink && modal) {
        logoutLink.addEventListener('click', function(event) { event.preventDefault(); modal.classList.remove('modal-hidden'); });
        function hideModal() { modal.classList.add('modal-hidden'); }
        if (cancelBtn) { cancelBtn.addEventListener('click', hideModal); }
        modal.addEventListener('click', function(event) { if (event.target === modal) { hideModal(); } });
    }

    // Script untuk editor pertanyaan
    const container = document.getElementById('question-editor-container');
    const addBtn = document.getElementById('add-question-btn');
    let questionCounter = container.querySelectorAll('.question-block').length;

    function addQuestionForm() {
        const questionIndex = questionCounter;
        const questionBlock = document.createElement('div');
        questionBlock.className = 'question-block';
        // Form untuk pertanyaan BARU tidak memiliki hidden input id_pertanyaan
        questionBlock.innerHTML = `
            <div class="question-header">
                <h4>Pertanyaan Baru #${questionIndex + 1}</h4>
                <div class="form-group-inline"><label>Poin</label><input type="number" class="poin-input" name="pertanyaan[${questionIndex}][poin]" value="10" min="1" required></div>
                <button type="button" class="btn-delete-question">&times;</button>
            </div>
            <div class="form-group"><label>Teks Pertanyaan</label><textarea name="pertanyaan[${questionIndex}][teks]" rows="3" required placeholder="Ketik teks pertanyaan baru di sini..."></textarea></div>
            <div class="options-grid">
                <div class="option-input-group"><input type="radio" name="pertanyaan[${questionIndex}][kunci]" value="A" required><label>A</label><input type="text" name="pertanyaan[${questionIndex}][opsi_a]" required placeholder="Opsi Jawaban A"></div>
                <div class="option-input-group"><input type="radio" name="pertanyaan[${questionIndex}][kunci]" value="B"><label>B</label><input type="text" name="pertanyaan[${questionIndex}][opsi_b]" required placeholder="Opsi Jawaban B"></div>
                <div class="option-input-group"><input type="radio" name="pertanyaan[${questionIndex}][kunci]" value="C"><label>C</label><input type="text" name="pertanyaan[${questionIndex}][opsi_c]" required placeholder="Opsi Jawaban C"></div>
                <div class="option-input-group"><input type="radio" name="pertanyaan[${questionIndex}][kunci]" value="D"><label>D</label><input type="text" name="pertanyaan[${questionIndex}][opsi_d]" required placeholder="Opsi Jawaban D"></div>
            </div>
        `;
        
        container.appendChild(questionBlock);
        questionBlock.querySelector('.btn-delete-question').addEventListener('click', function() {
            questionBlock.remove();
            updateQuestionNumbers();
        });
        questionCounter++;
        updateQuestionNumbers();
    }

    function updateQuestionNumbers() {
        const allQuestions = container.querySelectorAll('.question-block');
        allQuestions.forEach((block, index) => {
            // Hanya update nomor, bukan teks "Pertanyaan Baru"
            const h4 = block.querySelector('h4');
            if (!h4.textContent.includes('Baru')) {
                h4.textContent = `Pertanyaan #${index + 1}`;
            } else {
                 h4.textContent = `Pertanyaan Baru #${index + 1}`;
            }
        });
    }

    // Tambahkan event listener untuk tombol hapus pada pertanyaan yang sudah ada
    container.querySelectorAll('.btn-delete-question').forEach(btn => {
        btn.addEventListener('click', function() {
            this.closest('.question-block').remove();
            updateQuestionNumbers();
        });
    });

    addBtn.addEventListener('click', addQuestionForm);
});
</script>
</body>
</html>